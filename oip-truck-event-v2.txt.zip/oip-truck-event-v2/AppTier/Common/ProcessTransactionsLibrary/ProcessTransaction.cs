﻿using CDK.Data.OIP.API;
using PostToPartnerGenericProvider;
using System;
using System.Collections.Generic;
using System.Configuration;

namespace ProcessTransactionsLibrary
{
    public class ProcessTransaction :IProcessTransaction
    {
        /// <summary>
        /// ProcessMessage
        /// </summary>
        /// <param name="payLoad"></param>
        /// <param name="_dictHeaders"></param>
        public void ProcessMessage(String payLoad, Dictionary<string, string> _dictHeaders)
        {

            string strAppName = string.Empty;
            string strTransName = string.Empty;
            string strConversationId = string.Empty;
            string strConversationAppName = string.Empty;
            string strTransId = string.Empty;
            string strActivationId = string.Empty;
            string strVenders = string.Empty;
            string strErrorMessage = string.Empty;
            string strFilePath = string.Empty;
            string fileName = string.Empty;
            string fullfilepath = string.Empty;
            string strRoEventLogIncoming = "false";
            string strResponse = string.Empty;
            string strRetryCount = string.Empty;
            int intRetryCount = 0;
            try 
            {
                // Validate payLoad and Headers Begin
                if (payLoad == string.Empty || payLoad == null)
                {
                    strErrorMessage = "Invalid Request - payLoad not found.";
                    throw new Exception(strErrorMessage);
                }

                if (_dictHeaders.ContainsKey("AppName"))
                strAppName = _dictHeaders["AppName"].ToString();

                if (_dictHeaders.ContainsKey("TransName"))
                strTransName = _dictHeaders["TransName"].ToString();

                if (_dictHeaders.ContainsKey("ConversationId"))
                strConversationId = _dictHeaders["ConversationId"].ToString();

                if (_dictHeaders.ContainsKey("ConversationAppName"))
                strConversationAppName = _dictHeaders["ConversationAppName"].ToString();

                if (_dictHeaders.ContainsKey("TransId"))
                strTransId = _dictHeaders["TransId"].ToString();

                if (_dictHeaders.ContainsKey("ActivationId"))
                strActivationId = _dictHeaders["ActivationId"].ToString();

                if (_dictHeaders.ContainsKey("Venders"))
                strVenders = _dictHeaders["Venders"].ToString();

                if (_dictHeaders.ContainsKey("RetryCount"))
                strRetryCount = _dictHeaders["RetryCount"].ToString();

                if (strRetryCount != string.Empty)
                    intRetryCount = int.Parse(strRetryCount);
                else
                    _dictHeaders["RetryCount"] = intRetryCount.ToString();

                if (payLoad == string.Empty)
                {
                    strErrorMessage = "Invalid Request - payLoad not found.";
                    throw new Exception(strErrorMessage);
                }

                if (strAppName == string.Empty)
                {
                    strErrorMessage = "Invalid Request - AppName not found.";
                    throw new Exception(strErrorMessage);
                }
                if (strTransName == string.Empty)
                {
                    strErrorMessage = "Invalid Request - TransName not found.";
                    throw new Exception(strErrorMessage);
                }
                if (strConversationAppName == string.Empty)
                {
                    strErrorMessage = "Invalid Request - ConversationAppName not found.";
                    throw new Exception(strErrorMessage);
                }
                if (strConversationId == string.Empty)
                {
                    strErrorMessage = "Invalid Request - ConversationId not found.";
                    throw new Exception(strErrorMessage);
                }
                if (strTransId == string.Empty)
                {
                    strErrorMessage = "Invalid Request - TransId not found.";
                    throw new Exception(strErrorMessage);
                }
                if (strActivationId == string.Empty)
                {
                    strErrorMessage = "Invalid Request - ActivationId not found.";
                    throw new Exception(strErrorMessage);
                }

                if (strVenders == string.Empty)
                {
                    strErrorMessage = "Invalid Request - Venders not found.";
                    throw new Exception(strErrorMessage);
                }
                // Validate payLoad and Headers End

                //Log TimePoint2 SentToOEM Begin
                bool bResult = Convert.ToBoolean(TimePoints.MarkNext(strAppName, strTransId, 2, "ReceivedFromQueue"));
                if (!bResult)
                {
                    strErrorMessage = "Failed to mark second time point for Activation:" + strActivationId;
                    throw new Exception(strErrorMessage);
                }
                //Log TimePoint2 SentToOEM End

                // Complete TruckEvent paretnt transaction Begin
                string[] strVendersList = strVenders.Split(',');
                if (strVendersList != null && strVendersList.Length >0)
                    if (strVendersList[0].ToUpper() == strAppName.ToUpper())
                    {
                        TimePoints.MarkNext(strConversationAppName, strConversationId, 2, "Completed");
                        TimePoints.MarkNext(strConversationAppName, strConversationId, 3, "Completed");
                        TimePoints.MarkNext(strConversationAppName, strConversationId, 4, "Completed");
                    }
                // Complete TruckEvent paretnt transaction End

                int iExists = Routing.GetProperty(strAppName, "RoEventLogIncoming", ref strRoEventLogIncoming, Convert.ToInt32(strActivationId));
                if (!iExists.Equals(0))
                {
                    throw new Exception("Unable to retrieve RoEventLogIncoming property value from OIP Database. Please check under application " + strAppName + " the value for RoEventLogIncoming property.");
                }

                // Log incoming payLoad to filedep location FromDMS Begin
                bool isLogIncomming = (bool.Parse(ConfigurationManager.AppSettings["LogIncomming"]) || bool.Parse(strRoEventLogIncoming));
                _dictHeaders["strLogIncomming"] = isLogIncomming.ToString();
                if (isLogIncomming)
                {
                    strFilePath = ConfigurationManager.AppSettings["LogFromDMSPath"];
                    fileName = string.Format("{0}~{1}~{2}~FromDMS.xml", strAppName, strTransName, strTransId);
                    fullfilepath = System.IO.Path.Combine(string.Format(strFilePath, strAppName), fileName);
                    LogMessages(payLoad, fullfilepath, strAppName, strTransName, strTransId, strActivationId);
                }
                // Log incoming payLoad to filedep location FromDMS End

                //Log TimePoint3 SentToOEM Begin
                bResult = Convert.ToBoolean(TimePoints.MarkNext(strAppName, strTransId, 3, "SentToPartner"));
                if (!bResult)
                {
                    strErrorMessage = "Failed to mark third time point for Activation:" + strActivationId;
                    throw new Exception(strErrorMessage);
                }
                //Log TimePoint3 SentToOEM End

                //Post transactions to OEM Begin
                CommonProviderManager providerMgr = new CommonProviderManager();
                providerMgr.ExecuteProvider(strAppName.ToUpper());
                strResponse = providerMgr.Provider.PostMessageToPartner(payLoad, _dictHeaders);
                //Post transactions to OEM End

                if (!string.IsNullOrEmpty(strResponse))
                { 
                    //Log TimePoint4 completed Begin
                    bResult = Convert.ToBoolean(TimePoints.MarkNext(strAppName, strTransId, 4, "Completed"));
                    if (!bResult)
                    {
                        strErrorMessage = "Failed to mark fourth time point for Activation:" + strActivationId;
                        throw new Exception(strErrorMessage);
                    }
                    //Log TimePoint4 completed Begin
                }
            }
            catch (Exception ex)
            {
                TimePoints.MarkNext(strAppName, strTransId, 3, "FailedToPostToPartner");
                string strError = ex.Message.ToString() + strErrorMessage.ToString();
                ErrorLog.LogMessage("CDKTruckEventToOEMService", 3, strError, "", strAppName, strTransName, strTransId, strActivationId);
                //LogError payload Beging
                strFilePath = ConfigurationManager.AppSettings["LogFailedToPostToPartner"];
                //intRetryCount = intRetryCount + 1;
                fileName = string.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}.xml", strAppName, strTransName, strConversationId, strConversationAppName, strTransId, strActivationId, strVenders, intRetryCount);
                fullfilepath = System.IO.Path.Combine(string.Format(strFilePath, strAppName), fileName);
                LogMessages(payLoad, fullfilepath,strAppName, strTransName,strTransId,strActivationId);
                //LogError payload end
                //TimePoints.MarkNext(strAppName, strTransId, 4, "FailedToPostToPartner");
            }
        }

        /// <summary>
        /// LogMessages
        /// </summary>
        /// <param name="Payload"></param>
        /// <param name="strFilePath"></param>
        public void LogMessages(string Payload, string strFilePath, string strAppName, string strTransName, string strTransId, string strActivationId)
        {
            string strErrorMsg = string.Empty;
            try
            {
                System.IO.File.WriteAllText(strFilePath, Payload);
            }
            catch (Exception ex)
            {
                strErrorMsg = "Not able to log the file " + ex.Message;
                ErrorLog.LogMessage("CDKTruckEventToOEMService", 3, strErrorMsg, "", strAppName, strTransName, strTransId, strActivationId);
                //throw new Exception(strErrorMsg);
            }
        }
    }
}
