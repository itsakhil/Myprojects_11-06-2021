﻿namespace Truck.Common
{
    public interface IProcessMessage
    {
        bool ProcessMessage(string fileName, string data);
    }
}
