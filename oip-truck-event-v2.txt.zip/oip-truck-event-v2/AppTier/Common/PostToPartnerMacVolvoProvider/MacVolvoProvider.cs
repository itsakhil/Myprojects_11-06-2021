﻿using CDK.Data.OIP.API;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Diagnostics;
using System.Text;
using System.Xml.Serialization;

namespace PostToPartnerMacVolvoProvider
{
    public class MacVolvoProvider : PostToPartnerGenericProvider.CommonAbstractProvider
    {
        public override string PostMessageToPartner(string payLoad, Dictionary<string, string> dictHeaders)
        {
            string strAppName = string.Empty;
            string strTransName = string.Empty;
            string strConversationId = string.Empty;
            string strConversationAppName = string.Empty;
            string strTransId = string.Empty;
            string strActivationId = string.Empty;
            string strVenders = string.Empty;
            string strErrorMessage = string.Empty;
            string strReturnXML = string.Empty;
            string strPartnerURL = string.Empty;
            string strRetryCount = string.Empty;
            string strPayLoad = string.Empty;
            string strResponse = string.Empty;
            string strTransactionStatus = string.Empty;
            string strTranformed = string.Empty;
            string strDealerCode = string.Empty;


            string strMfrCode = string.Empty;
            int intRetryCount = 0;
            int intTimeout = 0;
            bool isLogIncomming = false;

            NameValueCollection nvc = new NameValueCollection();


           

            try
            {
                strAppName = dictHeaders["AppName"].ToString();
                strTransName = dictHeaders["TransName"].ToString();
                strConversationId = dictHeaders["ConversationId"].ToString();
                strConversationAppName = dictHeaders["ConversationAppName"].ToString();
                strTransId = dictHeaders["TransId"].ToString();
                strActivationId = dictHeaders["ActivationId"].ToString();
                strVenders = dictHeaders["Venders"].ToString();
                strRetryCount = dictHeaders["RetryCount"].ToString();
                if (strRetryCount != string.Empty)
                    intRetryCount = int.Parse(strRetryCount);
                isLogIncomming = (bool.Parse(dictHeaders["strLogIncomming"].ToString()));

                strPayLoad = payLoad;

                nvc.Add("CreatorNameCode", ConfigurationManager.AppSettings["CreatorNameCode"]);
                nvc.Add("SenderNameCode", ConfigurationManager.AppSettings["SenderNameCode"]);
                nvc.Add("DestinationNameCode", ConfigurationManager.AppSettings["DestinationNameCode"]);


                CDK.Data.OIP.API.Routing.GetProperty(strAppName, "MfrCode", ref strMfrCode, Convert.ToInt32(strActivationId));
                if(string.IsNullOrEmpty(strMfrCode))
                    throw new Exception("Error in PostMessageToPartner Mehtod : Unable to Retrive the MfrCode value from Properties");


                // Transform the document..

                ROTransformation.RepairOrder objRepaorOrde = new ROTransformation.RepairOrder();

                //DataSet ds = new DataSet();
               int iExists = CDK.Data.OIP.API.Routing.GetDealerCodeByActivation(Convert.ToInt32(strActivationId), ref strDealerCode);
                //Conversation.GetTransactionsByExtraProps(strAppName, strTransId, string.Empty, string.Empty, ref ds);
                //if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                //    strDealerCode = ds.Tables[0].Rows[0]["OEMDealerCode"].ToString();
                //else
                //    throw new Exception("Error in PostMessageToPartner Mehtod : Not able to fetch the DealerCode By Activation");
               if (string.IsNullOrEmpty(strDealerCode))
               {
                   throw new Exception("Error in PostMessageToPartner Mehtod : Not able to fetch the DealerCode By Activation");
               }

                if (strDealerCode.ToUpper().StartsWith(strMfrCode.ToUpper()))
                    strDealerCode = strDealerCode.Substring(strMfrCode.Length);


                strTranformed = objRepaorOrde.BuildROResponse(strDealerCode, strTransId, payLoad, nvc);

                // Log incoming payLoad to filedep location ToOEM Begin
                    if (isLogIncomming)
                {
                    string strFilePath = ConfigurationManager.AppSettings["LogToOEMPath"];
                    string fileName = string.Format("{0}~{1}~{2}~ToOEM.xml", strAppName, strTransName, strTransId);
                    string fullfilepath = System.IO.Path.Combine(string.Format(strFilePath, strAppName), fileName);
                    LogMessages(strTranformed, fullfilepath, strAppName, strTransName, strTransId, strActivationId);
                }

                Int32.TryParse(ConfigurationManager.AppSettings["Timeout"].ToString(), out intTimeout);

                Exception excp = PostToPartner(strTranformed, intTimeout, strActivationId, strAppName, strTransId, strMfrCode,strDealerCode,ref strResponse);

                if (excp == null)
                {
                    // Log response 
                    if (isLogIncomming)
                    {
                        string strFilePath = ConfigurationManager.AppSettings["LogFromOEMPath"];
                        string fileName = string.Format("{0}~{1}~{2}~CloseRO~FromOEM.xml", strAppName, strTransName, strTransId);
                        string fullfilepath = System.IO.Path.Combine(string.Format(strFilePath, strAppName), fileName);
                        LogMessages(strResponse, fullfilepath, strAppName, strTransName, strTransId, strActivationId);
                    }
                    // Log incoming payLoad to filedep location FromOEM End
                }
                else
                {
                    // Log response 
                    if (isLogIncomming)
                    {
                        string strFilePath = ConfigurationManager.AppSettings["LogFromOEMPath"];
                        string fileName = string.Format("{0}~{1}~{2}~CloseRO~FromOEM.xml", strAppName, strTransName, strTransId);
                        string fullfilepath = System.IO.Path.Combine(string.Format(strFilePath, strAppName), fileName);
                        LogMessages(strResponse, fullfilepath, strAppName, strTransName, strTransId, strActivationId);
                    }

                    throw new Exception(excp.Message);
                }
             
                
            }
            catch(Exception ex)
            {
                if (string.IsNullOrEmpty(strResponse))
                {
                    TimePoints.UpdateTransStatus(strAppName, strTransId,"FailedToPostToPartner");
                }
                else
                {
                    TimePoints.MarkNext(strAppName, strTransId, 4, "CompletedWithValidationErrors");
                }


                //LogError payload Beging
                ErrorLog.LogMessage("MacVolvoProvider", 3, FormatErrorMessage(ex.Message,true), "Error", strAppName, strTransName, strTransId, strActivationId);
                string strFilePath = ConfigurationManager.AppSettings["LogFailedToPostToPartner"];
                intRetryCount++;
                string fileName = string.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}.xml", strAppName, strTransName, strConversationId, strConversationAppName, strTransId, strActivationId, strVenders, intRetryCount);
                string fullfilepath = System.IO.Path.Combine(string.Format(strFilePath, strAppName), fileName);
                LogMessages(strPayLoad, fullfilepath, strAppName, strTransName, strTransId, strActivationId);
                return null;
            }
            return strResponse;
        }

        private Exception PostToPartner(string strPayLoad, int intTimeout, string strActivationId, string strAppName, string strTransId, string strMfrCode, string strDealerCode, ref string strResponse)
        {

            string strValue = string.Empty;
            Exception excep = null;
            string strUserName = string.Empty;
            string strPassword = string.Empty;
            string strKey=string.Empty;

            try
            {

                int iExists = Routing.GetProperty(strAppName, "MacVolvoEndpointURL", ref strValue, Convert.ToInt32(strActivationId));

                if (!iExists.Equals(0) || String.IsNullOrEmpty(strValue))
                {
                    throw new Exception("Unable to retrieve MacVolvoEndpointURL property value from OIP Database. Please check under application " + strAppName + " the value for MacVolvoEndpointURL property.");
                }

                iExists = Routing.GetProperty(strAppName, "MacVolvoUserName", ref strUserName, Convert.ToInt32(strActivationId));

                if (!iExists.Equals(0) || String.IsNullOrEmpty(strUserName))
                {
                    throw new Exception("Unable to retrieve MacVolvoUserName property value from OIP Database. Please check under application " + strAppName + " the value for MacVolvoUserName property.");
                }

                iExists = Routing.GetProperty(strAppName, "MacVolvoPwd", ref strPassword, Convert.ToInt32(strActivationId));

                if (!iExists.Equals(0) || String.IsNullOrEmpty(strPassword))
                {
                    throw new Exception("Unable to retrieve MacVolvoPwd property value from OIP Database. Please check under application " + strAppName + " the value for MacVolvoPwd property.");
                }
                strKey=ConfigurationManager.AppSettings["MacVolvoKey"].ToString();

                strUserName = CDK.Data.OIP.GenericUtility.Encryption.Decrypt(strUserName, strKey);

                if(string.IsNullOrEmpty(strUserName))
                    throw new Exception("Unable to Decrypt MacVolvoUserName property value. Please check under application " + strAppName + " the value for MacVolvoUserName property.");

                strPassword = CDK.Data.OIP.GenericUtility.Encryption.Decrypt(strPassword, strKey);

                if (string.IsNullOrEmpty(strPassword))
                    throw new Exception("Unable to Decrypt MacVolvoPwd property value. Please check under application " + strAppName + " the value for MacVolvoPwd property.");

                WsMqServices objWsMqServices = new WsMqServices();
                objWsMqServices.Url = strValue;
                objWsMqServices.Timeout = intTimeout;
                System.Net.NetworkCredential objAuth = new System.Net.NetworkCredential();
                objAuth.UserName = strUserName;
                objAuth.Password = strPassword;
                objWsMqServices.Credentials = objAuth;

                   

                MessageType objMessageType = new MessageType();

                MessageTypeBase64Payload objBase64Payload = new MessageTypeBase64Payload();
                objBase64Payload.Value = System.Text.Encoding.ASCII.GetBytes(strPayLoad);
                objMessageType.Base64Payload = objBase64Payload;

                //DataSet ds = new DataSet();
                ////iExists =  Routing.GetDealerCodeByActivation(Convert.ToInt32(strActivationId), ref strDealerCode);
                //iExists = Conversation.GetTransactionsByExtraProps(strAppName, strTransId, string.Empty, string.Empty, ref ds);
                //if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                //    strDealerCode = ds.Tables[0].Rows[0]["OEMDealerCode"].ToString();

                //if (strDealerCode.ToUpper().StartsWith(strMfrCode.ToUpper()))
                //    strDealerCode = strDealerCode.Substring(strMfrCode.Length);

                SendType objSendType = new SendType();

                HeaderType objHeader = new HeaderType();
                objHeader.Service = ConfigurationManager.AppSettings["Service"];
                objHeader.ServiceVersion = ConfigurationManager.AppSettings["ServiceVersion"];
                objHeader.SourceSystemName = ConfigurationManager.AppSettings["SourceSystemName"];
                objHeader.RoleId = string.Format("DealerCode-{0}", strDealerCode);
                objHeader.TrackingId = strTransId;

                DateTime dt = Convert.ToDateTime(DateTime.UtcNow.ToString("s") + "Z");
                objHeader.CreationTime = dt;

               

                HeaderTypeGIMHeader objMsgTimestamp=new HeaderTypeGIMHeader();
                objMsgTimestamp.Name ="GIMMsgTimestamp";
                objMsgTimestamp.Value = dt.ToString("yyyy-MM-ddTHH:mm:ssZ");

                HeaderTypeGIMHeader objGIMMsgType=new HeaderTypeGIMHeader();
                objGIMMsgType.Name ="GIMMsgType";
                objGIMMsgType.Value="ROTSCDK.xml";

                 HeaderTypeGIMHeader[] hdtTypeGIMhdr=new HeaderTypeGIMHeader[2];
                hdtTypeGIMhdr[0] = objMsgTimestamp;
                hdtTypeGIMhdr[1] = objGIMMsgType;

                objHeader.GIMHeader = hdtTypeGIMhdr;

                objSendType.Header = objHeader;

                //objSendType.Header.Service = ConfigurationManager.AppSettings["Service"];
                //objSendType.Header.ServiceVersion = ConfigurationManager.AppSettings["ServiceVersion"];
                //objSendType.Header.SourceSystemName = ConfigurationManager.AppSettings["SourceSystemName"];
                //objSendType.Header.RoleId = string.Format("DealerCode-{0}", strDealerCode);
                //objSendType.Header.TrackingId = strTransId;
                //objSendType.Header.CreationTime = Convert.ToDateTime(DateTime.UtcNow.ToString("s") + "Z");

                ReceiveType objResponse = new ReceiveType();

                objResponse = objWsMqServices.sendMessage(objSendType, objMessageType);

                strResponse = Serialize<ReceiveType>(objResponse);

                //strResponse = objResponse.Response.Result.Status.ToString();
                if (!objResponse.Response.Result.Status.ToString().ToUpper().Equals("SUCCESS"))
                {
                    throw new Exception("Got error Response from OEM : Error Message " + objResponse.Response.Result.ErrorMsg.ToString() + objResponse.Response.Result.ErrorCode.ToString());
                }
            }
            catch(Exception ex)
            {
                excep = ex;
            }
            return excep;

        }

        public string Serialize<T>(T dataToSerialize)
        {
            try
            {
                var stringwriter = new System.IO.StringWriter();
                var serializer = new XmlSerializer(typeof(T));
                serializer.Serialize(stringwriter, dataToSerialize);
                return stringwriter.ToString();
            }
            catch
            {
                throw;
            }
        }

        public void LogMessages(string Payload, string strFilePath, string strAppName, string strTransName, string strTransId, string strActivationId)
        {
            string strErrorMsg = string.Empty;
            try
            {
                System.IO.File.WriteAllText(strFilePath, Payload);
            }
            catch (Exception ex)
            {
                strErrorMsg = "Not able to log the file " + ex.Message;
                ErrorLog.LogMessage("MacVolvoProvider", 3, strErrorMsg, "", strAppName, strTransName, strTransId, strActivationId);
                // throw new Exception(strErrorMsg);
            }
        }

        public string FormatErrorMessage(string pMessage, bool pincludeComponent)
        {
            StackTrace st = new StackTrace();
            StackFrame sf = st.GetFrame(1);
            StringBuilder sb = new StringBuilder();
            sb.Append("Error in ").Append(sf.GetMethod().Name).Append(" method of ").Append(GetClassName());
            if (pincludeComponent)
            {
                sb.Append(" class of ").Append("MacVolvoProvider").Append(" component. ");
            }
            else
            {
                sb.Append(" class ");
            }

            sb.Append(string.Empty).Append(pMessage);
            return sb.ToString();
        }

        public string GetClassName()
        {
            return this.GetType().Name;
        }

    }
}
