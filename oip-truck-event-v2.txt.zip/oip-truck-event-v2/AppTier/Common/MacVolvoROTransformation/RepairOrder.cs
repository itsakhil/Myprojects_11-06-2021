﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Globalization;

namespace ROTransformation
{
    public class RepairOrder
    {
        public string component = "ROTransformation";

        public string BuildROResponse(string DealerCode, string BODID, string strPayload, NameValueCollection nvcParams)
        {
            XDocument xElemSORRequest = null;
            string strRes = string.Empty;
            try
            {
                XDocument xDocRO = XDocument.Parse(strPayload);

                XNamespace star = "http://www.starstandard.org/STAR/5";
                XNamespace oagis = "http://www.openapplications.org/oagis/9";

                XNamespace xns = xDocRO.Root.Name.Namespace.NamespaceName;

                XNamespace xsi = XNamespace.Get("http://www.w3.org/2001/XMLSchema-instance");
                XNamespace schemaLocation = XNamespace.Get("http://www.starstandard.org/STAR/5 ProcessRepairOrder.xsd");

                IEnumerable<XElement> XeleSRO = xDocRO.Descendants(xns + "ROInfo");

                xElemSORRequest =
                    new XDocument(
                        new XDeclaration("1.0", "utf-8", "true"),
                        new XElement(star + "ProcessRepairOrder", new XAttribute("releaseID", "a"), new XAttribute(XNamespace.Xmlns + "xsi", "http://www.w3.org/2001/XMLSchema-instance"), new XAttribute(XNamespace.Xmlns + "star", "http://www.starstandard.org/STAR/5"), new XAttribute(XNamespace.Xmlns + "oagis", "http://www.openapplications.org/oagis/9"), new XAttribute(xsi + "schemaLocation", schemaLocation),
                            new XElement(star + "ApplicationArea",
                                new XElement(star + "Sender",
                                  new XElement(star + "TaskID", "ReceiveROTimestamps"),
                                  new XElement(star + "CreatorNameCode", nvcParams.Get("CreatorNameCode")),
                                  new XElement(star + "SenderNameCode", nvcParams.Get("SenderNameCode")),
                                  new XElement(star + "DealerNumberID", DealerCode)), // Sender End
                                                                                      //new XElement("DealerCountryCode", nvcParams.Get("DealerCountryCode")),
                                                                                      //new XElement("LanguageCode", nvcParams.Get("LanguageCode"))), //Sender
                    new XElement(star + "CreationDateTime", DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ssZ")),
                        new XElement(star + "Destination",
                                  new XElement(star + "DestinationNameCode", nvcParams.Get("DestinationNameCode")))), // Destination End
                                                                                                                      //new XElement("DealerNumberID", DealerCode)),//Destination

                             //new XElement("BODID", BODID)),//ApplicationArea
                             new XElement(star + "ProcessRepairOrderDataArea",
                                 new XElement(star + "Process",
                                            new XElement(oagis + "ActionCriteria",
                                                new XElement(oagis + "ActionExpression", new XAttribute("actionCode", "Add"), "/RepairOrder"))),
                                 from XeleRO in XeleSRO
                                 select
                                    new XElement(star + "RepairOrder",
                                            new XElement(star + "RepairOrderHeader",
                                              new XElement(star + "DocumentIdentificationGroup",
                                               new XElement(star + "DocumentIdentification",
                                                new XElement(star + "DocumentID", GetkNodeValue(XeleRO.Element(xns + "RONumber"))))),
                                              new XElement(star + "DealerParty",
                                                new XElement(star + "PartyID", DealerCode)),
                                              new XElement(star + "OwnerParty",
                                               new XElement(star + "SpecifiedOrganization",
                                                   new XElement(star + "CompanyName", GetkNodeValuefromClc(XeleRO.Descendants(xns + "Name1"))),
                                                new XElement(star + "PrimaryContact",
                                                    new XElement(star + "TypeCode", ""),
                                                    new XElement(star + "PersonName", ""),
                                                   new XElement(star + "TelephoneCommunication",
                                                    new XElement(star + "ChannelCode", "Telephone"),
                                                    new XElement(star + "CompleteNumber", !string.IsNullOrEmpty(GetkNodeValuefromClc(XeleRO.Descendants(xns + "ContactPhone"))) ? GetkNodeValuefromClc(XeleRO.Descendants(xns + "ContactPhone")) : GetkNodeValuefromClc(XeleRO.Descendants(xns + "MainPhone")))),
                                                  new XElement(star + "URICommunication",
                                                    new XElement(star + "URIID", !string.IsNullOrEmpty(GetkNodeValuefromClc(XeleRO.Descendants(xns + "ContactEmail"))) ? GetkNodeValuefromClc(XeleRO.Descendants(xns + "ContactEmail")) : GetEmail(XeleRO.Descendants(xns + "Emails"))),
                                                    new XElement(star + "ChannelCode", "email"))))),  // SpecifiedOrganization End , OwnerParty End
                                               new XElement(star + "RepairOrderVehicleLineItem",
                                                new XElement(star + "Vehicle",
                                                  new XElement(star + "MakeString", GetMakeString(XeleRO.Descendants(xns + "VIN"), GetkNodeValuefromClc(XeleRO.Descendants(xns + "MakeCode")))),
                                                 new XElement(star + "VehicleIdentificationGroup",
                                                    new XElement(star + "VehicleID", GetkNodeValuefromClc(XeleRO.Descendants(xns + "VIN")))))),
                                               new XElement(star + "CASE",
                                                new XElement(star + "CaseTypeCode", "Other"),
                                                new XElement(star + "CaseNumberString", GetkNodeValue(XeleRO.Element(xns + "VendorRONumber")))), // Case End      

                                                new XElement(star + "RepairOrderOpenedDate", ConcateDateTime(GetkNodeValuefromClc(XeleRO.Descendants(xns + "OpenedDate")), GetkNodeValuefromClc(XeleRO.Descendants(xns + "OpenedTime")))),
                                                new XElement(star + "RepairOrderCompletedDate", ConcateDateTime(GetkNodeValuefromClc(XeleRO.Descendants(xns + "ClosedDate")), GetkNodeValuefromClc(XeleRO.Descendants(xns + "ClosedTime")))),
                                                new XElement(star + "RepairOrderInvoiceDate", ConvertToDateFormat(GetkNodeValuefromClc(XeleRO.Descendants(xns + "PostedDate")))),
                                              new XElement(star + "Splits",
                                                   new XElement(star + "SplitsTypeCode", "Total"),
                                                   new XElement(star + "CustomerPercent", CalculateCIWPercentage(XeleRO.Descendants(xns + "CustPayPercent"))),
                                                   new XElement(star + "InternalPercent", CalculateCIWPercentage(XeleRO.Descendants(xns + "IntPayPercent"))),
                                                   new XElement(star + "WarrantyPercent", CalculateCIWPercentage(XeleRO.Descendants(xns + "WarPayPercent")))),
                                                new XElement(star + "LaborActualHoursNumeric", ActualHours(XeleRO)),
                                                new XElement(star + "PromisedRepairCompletionDate", ConvertToDateFormat(GetkNodeValuefromClc(XeleRO.Descendants(xns + "PromiseDate"))))),  //RepairOrderHeader End

                                                ROLines(XeleRO)

                                                //new XElement("Job",
                                                //  new XElement("JobNumberString", GetkNodeValue(XeleRO.Element(xns +"OpCodeKey"))),
                                                //  new XElement("OperationID", GetkNodeValue(XeleRO.Element(xns +"OpCode"))),
                                                //  new XElement("OperationName", GetkNodeValue(XeleRO.Element(xns +"OpCodeDesc"))),
                                                //  new XElement("CodesAndCommentsExpanded",string.Empty),
                                                //  new XElement("Diagnostics",string.Empty),
                                                //  new XElement("ServiceParts",
                                                //     new XElement("ItemQuantity", GetkNodeValue(XeleRO.Element(xns +"QtyFilled"))),
                                                //     new XElement("ItemInstalledPurchaseDate", GetkNodeValue(XeleRO.Element(xns +"OrderDate"))),
                                                //     new XElement("ItemIdentificationGroup",
                                                //      new XElement("ItemIdentification",
                                                //      new XElement("ItemID", new XAttribute("schemeID", "PartNumber"), GetkNodeValue(XeleRO.Element(xns +"ID")))))), // ServiceParts End                  
                                                //  new XElement("ServiceLabor",
                                                //     new XElement("LaborOperationID", GetkNodeValue(XeleRO.Element(xns +"OpCode"))),
                                                //     new XElement("CompletionDateTime", GetkNodeValue(XeleRO.Element(xns +"FinishTime"))),
                                                //     new XElement("StartDateTime", GetkNodeValue(XeleRO.Element(xns +"StartTime")))),// ServiceLabor End                  
                                                //   new XElement("LaborActualHoursNumeric", ActualHours(XeleRO)),
                                                //  new XElement("ServiceTechnicianParty",""))  // Job End 

                                                )//RepairOrder End
                                                )//ProcessRepairOrderDataArea End
                                                )//ProcessRepairOrder
                                                );//XDocument


                strRes = xElemSORRequest.Root.Document.ToString();
                //  strRes = strRes.Replace(":ns0", "");
            }
            catch (Exception ex)
            {
                throw new Exception(FormatErrorMessage(ex.Message, true));
            }



            return strRes;
        }

        public string GetMakeString(IEnumerable<XElement> XeleRO, string MakeCode)
        {
            string strValue = string.Empty;
            try
            {
                if (XeleRO != null && XeleRO.Count() > 0)
                {
                    strValue = XeleRO.FirstOrDefault().Value;

                    if (strValue.Trim().ToUpper().StartsWith("4V"))
                        strValue = "Volvo";
                    else if (strValue.Trim().ToUpper().StartsWith("1M") || strValue.Trim().ToUpper().StartsWith("8XG"))
                        strValue = "Mack";
                    else
                        strValue = MakeCode;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(FormatErrorMessage("Unable to find the node" + XeleRO + ex.Message, false));
            }
            return strValue;
        }

        public string CalculateCIWPercentage(IEnumerable<XElement> XeleRO)
        {
            //string strValue = string.Empty;
            //IEnumerable<XElement> xeleLbrLines = null;

            //XNamespace xns = XeleRO.Name.Namespace.NamespaceName;
            //double percetange = 0;
            //try
            //{
            //    if (XeleRO != null)
            //    {

            //        xeleLbrLines = XeleRO.Descendants(xns + "Operation");
            //        if (xeleLbrLines != null)
            //        {
            //            foreach (XElement xele in xeleLbrLines)
            //            {
            //                if (xele.Element(xns + "OpLaborType") != null)
            //                {
            //                    if (xele.Element(xns + "OpLaborType").Value.ToUpper().Trim().StartsWith(Type))
            //                    {
            //                        percetange = percetange + Convert.ToDouble(GetkNodeValue(xele.Element(xns + "CostAmount")));
            //                    }
            //                }
            //            }

            //        }

            //        if (percetange > 0)
            //            percetange = percetange / 100;
            //    }
            //}
            //catch (Exception ex)
            //{
            //    throw new Exception(FormatErrorMessage("Unable to find the node" + XeleRO + ex.Message, false));
            //}
            //return percetange.ToString("N2").Replace(",", "");

            string strValue = string.Empty;
            double percentage = 0;
            try
            {
                if (XeleRO != null && XeleRO.Count() > 0)
                {
                    strValue = XeleRO.FirstOrDefault().Value;
                    if (!string.IsNullOrEmpty(strValue))
                    {
                        percentage = Convert.ToDouble(strValue);
                        strValue = percentage.ToString("N2").Replace(",", "");
                    }
                    else strValue = "0.0";

                }
            }
            catch (Exception ex)
            {
                throw new Exception(FormatErrorMessage("Unable to find the node" + XeleRO + ex.Message, false));
            }
            return strValue;
        }


        public string GetEmail(IEnumerable<XElement> XeleRO)
        {
            string strValue = string.Empty;
            IEnumerable<XElement> xeleEmails = null;

            try
            {
                if (XeleRO != null)
                {
                    XNamespace xns = XeleRO.SingleOrDefault().Name.Namespace.NamespaceName;
                    xeleEmails = XeleRO.Descendants(xns + "Email");
                    if (xeleEmails != null)
                    {
                        foreach (XElement xele in xeleEmails)
                        {
                            if (xele.Element(xns + "EmailAddress") != null && !string.IsNullOrEmpty(xele.Element(xns + "EmailAddress").Value))
                            {
                                strValue = xele.Element(xns + "EmailAddress").Value;
                                break;
                            }
                        }

                    }

                }
            }
            catch (Exception ex)
            {
                throw new Exception(FormatErrorMessage("Unable to find the node" + XeleRO + ex.Message, false));
            }
            return strValue;
        }

        public string ActualHours(XElement XeleRO)
        {
            string strValue = string.Empty;
            IEnumerable<XElement> xeleLbrLines = null;
            XNamespace xns = XeleRO.Name.Namespace.NamespaceName;

            double totalhrs = 0;
            try
            {
                if (XeleRO != null)
                {

                    xeleLbrLines = XeleRO.Descendants(xns + "Operation");
                    if (xeleLbrLines != null)
                    {
                        foreach (XElement xele in xeleLbrLines)
                        {
                            if (xele.Element(xns + "ActualHours") != null & !string.IsNullOrEmpty(xele.Element(xns + "ActualHours").Value))
                            {
                                totalhrs = totalhrs + Convert.ToDouble(xele.Element(xns + "ActualHours").Value);
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(FormatErrorMessage("Unable to find the node" + XeleRO + ex.Message, false));
            }
            return totalhrs.ToString();
        }


        public string VehicleOptions(string strData, string strKey)
        {
            string strVal = string.Empty;

            if (!string.IsNullOrEmpty(strData))
            {
                string[] strCollection = strData.Split(',');

                foreach (string strmsg in strCollection)
                {
                    if (strmsg.Contains(strKey + ":"))
                    {
                        strVal = strmsg.Replace(strKey, "").Replace(":", "");
                    }
                }

            }
            return strVal;
        }

        public string GetkNodeValue(XElement XeleRO)
        {
            string strValue = string.Empty;
            try
            {
                if (XeleRO != null)
                {
                    strValue = XeleRO.Value;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(FormatErrorMessage("Unable to find the node" + XeleRO + ex.Message, false));
            }
            return strValue;
        }

        public string ConvertToDateFormat(string date)
        {
            if (!string.IsNullOrEmpty(date))
                return date = Convert.ToDateTime(date).ToString("yyyy-MM-dd");
            else
                return date;

        }

        public string ConcateDateTime(string date, string time)
        {
            string strValue = string.Empty;
            try
            {
                DateTime dt1 = DateTime.Parse(date + " " + time, CultureInfo.InvariantCulture);
                //strValue = string.Format("{0}T{1}Z",GetkNodeValuefromClc(XeleLine.Descendants(xns + "Date")),GetkNodeValuefromClc(XeleLine.Descendants(xns + "StartTime")));
                strValue = dt1.ToString("yyyy-MM-ddTHH:mm:ssZ");
            }
            catch (Exception)
            {

            }
            return strValue;
        }
        public string GetkNodeValuefromClc(IEnumerable<XElement> XeleRO)
        {
            string strValue = string.Empty;
            try
            {
                if (XeleRO != null && XeleRO.Count() > 0)
                {
                    strValue = XeleRO.FirstOrDefault().Value;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(FormatErrorMessage("Unable to find the node" + XeleRO + ex.Message, false));
            }
            return strValue;
        }

        public IEnumerable<XElement> ROLines(XElement XeleRO)
        {
            XElement xeleLines = null;
            //IEnumerable<XElement> xeleFinalLines = null;
            XElement xeleFinalLines = new XElement("Lines");
            XNamespace star = "http://www.starstandard.org/STAR/5";
            try
            {
                XNamespace xns = XeleRO.Name.Namespace.NamespaceName;

                foreach (XElement xeleline in XeleRO.Descendants(xns + "LaborLine"))
                {
                    xeleLines = new XElement(star + "Job",
                    new XElement(star + "JobNumberString", GetkNodeValuefromClc(xeleline.Descendants(xns + "OpCodeKey"))),
                    new XElement(star + "OperationID", GetkNodeValuefromClc(xeleline.Descendants(xns + "OpCode"))),
                    new XElement(star + "OperationName", GetkNodeValuefromClc(xeleline.Descendants(xns + "OpCodeDesc"))),
                    new XElement(star + "CodesAndCommentsExpanded", string.Empty),
                    new XElement(star + "Diagnostics", string.Empty),
                    ROParts(xeleline),
                    ROLabor(xeleline),
                    new XElement(star + "LaborActualHoursNumeric", GetkNodeValuefromClc(xeleline.Descendants(xns + "ActualHours"))),
                    new XElement(star + "ServiceTechnicianParty", ""));  // Job End 
                    xeleFinalLines.Add(xeleLines);

                }


            }
            catch (Exception ex)
            {
                throw new Exception(FormatErrorMessage(ex.Message, false));
            }
            return xeleFinalLines.Descendants(star + "Job");
        }

        public IEnumerable<XElement> ROParts(XElement XeleLine)
        {
            XElement xeleParts = null;
            XElement xeleFinalParts = new XElement("PartsList");
            XNamespace star = "http://www.starstandard.org/STAR/5";
            try
            {
                XNamespace xns = XeleLine.Name.Namespace.NamespaceName;
                foreach (XElement xelePart in XeleLine.Descendants(xns + "Part"))
                {
                    xeleParts = new XElement(star + "ServiceParts",
                    new XElement(star + "ItemQuantity", GetkNodeValue(xelePart.Element(xns + "QtyFilled"))),
                    new XElement(star + "ItemOriginalPurchaseDate", ConvertToDateFormat(GetkNodeValue(xelePart.Element(xns + "OrderDate")))),
                    new XElement(star + "ItemIdentificationGroup",
                    new XElement(star + "ItemIdentification",
                    new XElement(star + "ItemID", new XAttribute("schemeID", "PartNumber"), GetkNodeValue(xelePart.Element(xns + "ID")))),
                     new XElement(star + "ItemIdentification",
                    new XElement(star + "ItemID", new XAttribute("schemeID", "OrderNumber"), GetkNodeValue(xelePart.Element(xns + "OrderNumber")))))); // ServiceParts End          

                    xeleFinalParts.Add(xeleParts);
                }

            }
            catch (Exception ex)
            {
                throw new Exception(FormatErrorMessage(ex.Message, false));
            }
            return xeleFinalParts.Descendants(star + "ServiceParts");
        }

        public IEnumerable<XElement> ROLabor(XElement XeleLine)
        {
            XElement xeleLabor = null;
            XElement xeleFinalLabor = new XElement("LaborList");
            XNamespace star = "http://www.starstandard.org/STAR/5";
            int iOpCnt = 0;
            try
            {
                XNamespace xns = XeleLine.Name.Namespace.NamespaceName;

                foreach (XElement xeleLbr in XeleLine.Descendants(xns + "Operation"))
                {
                    iOpCnt++;
                    foreach (XElement XelePunch in XeleLine.Descendants(xns + "PunchTimes").Elements())
                    {
                        xeleLabor = new XElement(star + "ServiceLabor",
                    new XElement(star + "LaborOperationID", GetkNodeValue(xeleLbr.Element(xns + "OpCode"))),
                    new XElement(star + "LaborActionCode", new XAttribute("name", GetLaborTimeStamp(XelePunch, "ActionAtt", iOpCnt)), GetLaborTimeStamp(XelePunch, "ActionCode", iOpCnt)),
                    new XElement(star + "CompletionDateTime", GetLaborTimeStamp(XelePunch, "FinishtTime", iOpCnt)),
                    new XElement(star + "StartDateTime", GetLaborTimeStamp(XelePunch, "StartTime", iOpCnt)));// ServiceLabor End            
                        xeleFinalLabor.Add(xeleLabor);
                        if (iOpCnt > 1)
                            break;
                    }


                }

            }
            catch (Exception ex)
            {
                throw new Exception(FormatErrorMessage(ex.Message, false));
            }
            return xeleFinalLabor.Descendants(star + "ServiceLabor");
        }


        private string GetLaborTimeStamp(XElement XelePunch, string type, int iOpCnt)
        {
            string strValue = string.Empty;

            try
            {
                if (XelePunch != null)
                {
                    XNamespace xns = XelePunch.Name.Namespace.NamespaceName;
                    //IEnumerable<XElement> XelePunch = XeleLine.Descendants(xns + "PunchTime");
                    //IEnumerable<XElement> XeleLbr = XeleLine.Descendants(xns + "Operation");

                    if (iOpCnt == 1)
                    {
                        //if (XelePunch != null && XelePunch.Count() > 0)
                        //{
                        if (type.Equals("StartTime"))
                        {
                            if (!string.IsNullOrEmpty(GetkNodeValuefromClc(XelePunch.Descendants(xns + "Date"))))
                            {
                                DateTime dt1 = DateTime.Parse(GetkNodeValuefromClc(XelePunch.Descendants(xns + "Date")) + " " + GetkNodeValuefromClc(XelePunch.Descendants(xns + "StartTime")), CultureInfo.InvariantCulture);
                                //strValue = string.Format("{0}T{1}Z",GetkNodeValuefromClc(XeleLine.Descendants(xns + "Date")),GetkNodeValuefromClc(XeleLine.Descendants(xns + "StartTime")));
                                strValue = dt1.ToString("yyyy-MM-ddTHH:mm:ssZ");
                            }
                        }
                        else if (type.Equals("FinishtTime"))
                        {
                            if (!string.IsNullOrEmpty(GetkNodeValuefromClc(XelePunch.Descendants(xns + "Date"))))
                            {
                                DateTime dt1 = DateTime.Parse(GetkNodeValuefromClc(XelePunch.Descendants(xns + "Date")) + " " + GetkNodeValuefromClc(XelePunch.Descendants(xns + "FinishTime")), CultureInfo.InvariantCulture);
                                //strValue = string.Format("{0}T{1}Z", GetkNodeValuefromClc(XeleLine.Descendants(xns + "Date")), GetkNodeValuefromClc(XeleLine.Descendants(xns + "FinishTime")));
                                strValue = dt1.ToString("yyyy-MM-ddTHH:mm:ssZ");
                            }
                        }
                        else if (type.Equals("ActionCode"))
                        {
                            strValue = "A";
                        }
                        else if (type.Equals("ActionAtt"))
                        {
                            strValue = "ClockTimesActual";
                        }
                        // }
                    }
                    else
                    {
                        //if (XelePunch != null && XelePunch.Count() > 0)
                        //{
                        if (type.Equals("StartTime"))
                        {
                            DateTime dt1 = DateTime.Parse(GetkNodeValuefromClc(XelePunch.Descendants(xns + "Date")) + " " + "00:00:00", CultureInfo.InvariantCulture);
                            //strValue = string.Format("{0}T{1}Z", GetkNodeValuefromClc(XeleLine.Descendants(xns + "Date")), "00:00:00");
                            strValue = dt1.ToString("yyyy-MM-ddTHH:mm:ssZ");
                        }
                        else if (type.Equals("FinishtTime"))
                        {
                            DateTime dt1 = DateTime.Parse(GetkNodeValuefromClc(XelePunch.Descendants(xns + "Date")) + " " + "00:00:00", CultureInfo.InvariantCulture);
                            //strValue = string.Format("{0}T{1}Z", GetkNodeValuefromClc(XeleLine.Descendants(xns + "Date")), "00:00:00");
                            strValue = dt1.ToString("yyyy-MM-ddTHH:mm:ssZ");
                        }
                        else if (type.Equals("ActionCode"))
                        {
                            strValue = "E";
                        }
                        else if (type.Equals("ActionAtt"))
                        {
                            strValue = "ClockTimesEstimated";
                        }
                        //}
                    }

                    //if (XelePunch == null && XelePunch.Count() > 0)
                    //{
                    //}

                }

            }
            catch (Exception ex)
            {
                throw new Exception(FormatErrorMessage("Unable to calculate the Start/Finish Dates " + ex.Message, false));
            }
            return strValue;
        }

        public string CheckNodeType(XElement XeleRO, int iIndex)
        {
            string strVal = string.Empty;
            try
            {
                if (XeleRO != null && XeleRO.HasElements)
                {
                    if (XeleRO.Elements("V") != null && XeleRO.Elements("V").Where(i => i.Attributes("Idx").SingleOrDefault().Value == iIndex.ToString()).SingleOrDefault() != null)
                        strVal = XeleRO.Elements("V").Where(i => i.Attributes("Idx").SingleOrDefault().Value == iIndex.ToString()).SingleOrDefault().Value;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(FormatErrorMessage("Unable to find the node" + XeleRO + ex.Message, false));
            }
            return strVal;
        }

        public string FormatErrorMessage(string pMessage, bool pincludeComponent)
        {
            StackTrace st = new StackTrace();
            StackFrame sf = st.GetFrame(1);
            StringBuilder sb = new StringBuilder();
            sb.Append("Error in ").Append(sf.GetMethod().Name).Append(" method of ").Append(GetClassName());
            if (pincludeComponent)
            {
                sb.Append(" class of ").Append(component).Append(" component. ");
            }
            else
            {
                sb.Append(" class ");
            }

            sb.Append(string.Empty).Append(pMessage);
            return sb.ToString();


        }

        public string GetClassName()
        {
            return this.GetType().Name;
        }
    }
}
