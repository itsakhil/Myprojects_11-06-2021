﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gropbyowner
{
    class Program
    {
        static void Main(string[] args)
        {

            Dictionary<string, string> dict = new Dictionary<string, string>();

            var flag = 'Y';
            string key = string.Empty;
            string val = string.Empty;
            for (int i = 1; ; i++)
            {
                if (flag.Equals('y') || flag.Equals('Y'))
                {
                    Console.WriteLine("Enter File Name");
                    key = Console.ReadLine();
                    if (string.IsNullOrEmpty(key))
                    {
                        Console.WriteLine("Error: Enter valid File ");
                        key = Console.ReadLine();
                    }

                    Console.WriteLine("Enter Owner Name");
                    val = Console.ReadLine();
                    if (string.IsNullOrEmpty(val))
                    {
                        Console.WriteLine("Error: Enter valid Author");
                        val = Console.ReadLine();
                    }

                    Console.WriteLine("Press Y if you want to enter More else press N");
                    flag = char.Parse(Console.ReadLine());
                    dict.Add(key, val);

                }
                else
                {
                    break;
                }
            }

            var c = dict.GroupBy(o => o.Value).ToList();
          
            string res = string.Empty;
            Dictionary<string, string> dic_result = new Dictionary<string, string>();
            foreach (var item in c)
            {
                string data = string.Empty;
                var files_author = dict.Where(b => b.Value.Equals(item.Key)).ToDictionary(g => g.Key, g => g.Value);
                foreach (var files in files_author)
                {

                    if (string.IsNullOrEmpty(data))
                    {
                        data = string.Format("'{0}'", files.Key);
                    }
                    else
                    {
                        data += string.Format(",'{0}'", files.Key);
                    }
                    

                }
                
                 res+=string.Format("'{0}':[{1}]", item.Key, data);
               

              
            }
            res = "{" + res + "}";
            Console.WriteLine(res);


            
            Console.ReadKey();
        }
        
    }
    
}
