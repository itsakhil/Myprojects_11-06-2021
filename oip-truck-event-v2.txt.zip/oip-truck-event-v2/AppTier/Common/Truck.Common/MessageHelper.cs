﻿using CDK.Data.OIP.API;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;

namespace Truck.Common
{
    public class MessageHelper
    {
        public string TransName { get; set; }
        public string ActivationID { get; set; }
        public string TransId { get; set; }
        public string Venders { get; set; }
        public string ConversationID { get; set; }
        public string ConversationName { get; set; }
        public string VenderOnly { get; set; }

        private string _retryCount = "0";

        private string RetryCount
        {
            get { return _retryCount; }
            set { _retryCount = value; }
        }

        private string strComponent = "TruckServertoOEMWCFService";

        public Dictionary<string, string> GetDefaultProperties(string fileName, string appName, string conversationAppName)
        {
            var properties = Path.GetFileNameWithoutExtension(fileName).Split('~');
            VenderOnly = properties[0];
            ActivationID = properties[1];
            ConversationID = properties[2];
            TransId = properties[3];
            TransName = properties[4];
            RetryCount = properties[5];


            if (VenderOnly == null || TransName == null || TransId == null)
            {
                throw new Exception("Venders or TransName or TransID not present in properties");
            }

            //VenderOnly = string.Join(",", Venders.Split(',').Select(a => a.Split(':').First()));
            //ConversationID = TransId;
            ConversationName = conversationAppName;
            var propertiesCollection = new Dictionary<string, string>();
            propertiesCollection.Add("AppName", appName);
            propertiesCollection.Add("TransName", TransName);
            propertiesCollection.Add("ConversationId", ConversationID);
            propertiesCollection.Add("TransId", TransId);
            propertiesCollection.Add("ActivationId", ActivationID);
            propertiesCollection.Add("Venders", VenderOnly);
            propertiesCollection.Add("ConversationAppName", conversationAppName);
            propertiesCollection.Add("RetryCount", RetryCount);
            return propertiesCollection;
        }

        public void MarkTimePoint(Dictionary<string, string> collection)
        {
            TimePoints.MarkFirst(collection["AppName"], collection["TransName"], collection["TransId"], Convert.ToInt32(collection["ActivationId"]), "Initiated",
                "Conversationid: " + collection["ConversationId"], string.Empty, 1);
            Conversation.ConversationAddTransaction(collection["ConversationId"], collection["AppName"], TransId);
        }

        public void LogErrorinFile(string filePath, byte[] payload, string appName)
        {
            // fileName = string.Format("{0}~{1}~{2}~{3}~Subscriber.xml", appName, TransName, TransId, Venders.Replace(':','$'));
            var fileName = string.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}.xml", appName, TransName, ConversationID, ConversationName, TransId, ActivationID, VenderOnly,
                RetryCount);
            var strLogFolder = string.Format(filePath, TransName);
            File.WriteAllBytes(Path.Combine(strLogFolder, fileName), payload);
        }

        public string FormatErrorMessage(string pMessage, bool pincludeComponent)
        {
            StackTrace st = new StackTrace();
            StackFrame sf = st.GetFrame(1);
            StringBuilder sb = new StringBuilder();
            sb.Append("Error in ").Append(sf.GetMethod().Name).Append(" method of ").Append(GetClassName());
            if (pincludeComponent)
            {
                sb.Append(" class of ").Append(strComponent).Append(" component. ");
            }
            else
            {
                sb.Append(" class ");
            }

            sb.Append(string.Empty).Append(pMessage);
            return sb.ToString();
        }

        public string GetClassName()
        {
            return GetType().Name;
        }
    }
}
