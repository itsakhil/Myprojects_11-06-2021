﻿using CDK.Data.OIP.API;
using HttpRequestProcessor;
using System;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

namespace TruckDMStoiServerEventingHandler
{
    public class RequestProcessor
    {
        private HttpRequest request;
        private string strErrorMsg = string.Empty;
        private TransactionDetails transactionInfo;
        private string strComponent = "TruckDMStoiServerEventingHandler";
        private byte[] payloadBytes;
        private string logMessagePath;
        public string ErrorMessage
        {
            get { return strErrorMsg; }
        }


        public RequestProcessor(HttpRequest httpRequest)
        {
            try
            {
                request = httpRequest;
                payloadBytes = request.BinaryRead(request.TotalBytes);
                transactionInfo = GetTransactionInfo();
                logMessagePath = ConfigurationManager.AppSettings["LogIncomingLocation"];
            }
            catch (Exception exception)
            {
                ErrorLog.LogMessage(strComponent, 3,
                    string.Format("exception: {0} stackTrace: {1}", exception, exception.StackTrace));
            }
        }

        private TransactionDetails GetTransactionInfo()
        {
            return new TransactionDetails()
            {
                AppName = request.QueryString["AppName"],
                TransName = request.QueryString["TransName"],
                TransId = request.QueryString["TransID"],
                Venders = request.Headers["Vendors"],
                //Venders = request.QueryString["Venders"]
                RetryCount = String.IsNullOrEmpty(request.QueryString["RetryCount"]) ? 0 : Convert.ToInt32(request.QueryString["RetryCount"]) + 1
            };
        }

        public string ProcessRequest(out int statusCode)
        {
            try
            {
                var exchangeName = ConfigurationManager.AppSettings[transactionInfo.TransName];
                // After validation First Timepoint will be called
                TimePoints.MarkFirst(transactionInfo.AppName, transactionInfo.TransName,
                    transactionInfo.TransId, ConfigurationManager.AppSettings["DealorCode"], "Initiated",
                    transactionInfo.TransId, transactionInfo.Venders, 1);

                //logRequest(payloadBytes, logMessagePath, false);
                ServerAPIHelper serverApiHelper = new ServerAPIHelper(transactionInfo);
                CreateConversation(serverApiHelper);

                serverApiHelper.SendMesageWithTP(exchangeName, payloadBytes);

                statusCode = 200;
            }
            catch (Exception exception)
            {
                statusCode = 500;
                strErrorMsg = "Internal Error Occured";
                //todo: what to do with exception
                ErrorLog.LogMessage("ProcessRequest", 3, FormatErrorMessage(exception.ToString(), true), String.Empty,
                    transactionInfo.AppName, transactionInfo.TransName, transactionInfo.TransId, String.Empty);
                logRequest(payloadBytes, ConfigurationManager.AppSettings["ErrorSaveLocation"], true);
            }
            if (string.IsNullOrEmpty(strErrorMsg) && statusCode == 200)
            {
                strErrorMsg = CreateResponse(true, strErrorMsg, 200);
            }
            return strErrorMsg;
        }

        public bool VerifyTransaction()
        {
            var dataset = new DataSet();
            try
            {
                // Check Duplicate
                DataSet checkduplicateDataSet = null;
                if (ConfigurationManager.AppSettings["CheckDuplicateTrans"].Equals("true",
                    StringComparison.OrdinalIgnoreCase))
                {
                    int count = 0;
                    TimePoints.GetTransactionInfo(transactionInfo.TransId,
                        ref checkduplicateDataSet, ref count);
                    if (checkduplicateDataSet != null && checkduplicateDataSet.Tables.Count > 0 &&
                        checkduplicateDataSet.Tables[0].Rows.Count > 0)
                    {
                        strErrorMsg = strErrorMsg + " Duplicate transaction found for TransactionID: " +
                                      transactionInfo.TransId;
                        ErrorLog.LogMessage(strComponent, 3,
                             " Duplicate transaction found for TransactionID: " + transactionInfo.TransId, string.Empty,
                             transactionInfo.AppName, transactionInfo.TransName, transactionInfo.TransId,
                             ConfigurationManager.AppSettings["DealorCode"]);
                        return false;
                    }
                }

                StringBuilder sbVendors = new StringBuilder();

                foreach (var vender in transactionInfo.Venders.Split(','))
                {
                    var venderdetail = vender.Split(':');
                    var appName = venderdetail.First();
                    var activationId = venderdetail.Last();
                    dataset = new DataSet();

                    /*
                    string dealerCode=String.Empty;
                    Routing.GetDealerCodeByActivation(Convert.ToInt32(activationId), ref dealerCode);
                    if (string.IsNullOrEmpty(dealerCode))
                    {
                        strErrorMsg = strErrorMsg + " Invalid Activation ID transmitted – Verify Setups. ";
                        return false;
                    }
                     */



                    Routing.GetConnectInfo(appName, Convert.ToInt32(activationId), ref dataset);
                    if (dataset == null || dataset.Tables.Count == 0 || dataset.Tables[0].Rows.Count == 0)
                    {
                        strErrorMsg = strErrorMsg + " Activation " + activationId + " does not exists – Verify Setups. ";
                        //return false;
                    }
                    else if (dataset.Tables.Count > 0 && dataset.Tables[0].Rows.Count > 0 &&
                             !appName.Equals(dataset.Tables[0].Rows[0]["Name"].ToString().Trim(),
                                 StringComparison.OrdinalIgnoreCase))
                    {
                        strErrorMsg = strErrorMsg + " Invalid Application name " + appName + " transmitted – Verify Setups. ";
                        //return false;
                    }
                    else
                    {
                        sbVendors.Append(vender).Append(",");
                    }

                }

                transactionInfo.Venders = sbVendors.ToString().TrimEnd(',');

                if (!logRequest(payloadBytes, logMessagePath, false))
                {
                    strErrorMsg = "Unable to Log payload to path " + logMessagePath;
                    return false;
                }
            }
            catch(Exception ex)
            {
                strErrorMsg = ex.Message;
                return false;
            }
            finally
            {
                dataset.Dispose();
            }


            return true;
        }

        private void CreateConversation(ServerAPIHelper serverApiHelper)
        {
            try
            {
                serverApiHelper.CreateConversation();
                transactionInfo.GenerateVenderDetails();
                foreach (var vender in transactionInfo.VendersDictionary)
                {
                    //vender.TransId = Guid.NewGuid().ToString();
                    serverApiHelper.AddTransactionInConversation(vender);
                }
            }
            catch (Exception exception)
            {
                // need to throw exception
                ErrorLog.LogMessage("CreateConversation", 3, FormatErrorMessage(exception.ToString(), true),
                    string.Empty, transactionInfo.AppName, transactionInfo.TransName, transactionInfo.TransId,
                    String.Empty);
                throw;
            }
        }

        public bool logRequest(byte[] payloadBytes, string loglocation, bool isError)
        {
            try
            {
                string strRoEventLogIncomming = string.Empty;
                if (
                    ConfigurationManager.AppSettings["LogIncoming"].Equals("true", StringComparison.OrdinalIgnoreCase) ||
                    isError)
                {
                    //var fileFormat = isError ? "{0}~{1}~{2}~{3}~{4}.xml" : "{0}~{1}~{2}~{3}.xml";
                    var fileName = string.Format("{0}~{1}~{2}~{3}~FromDMS~{4}.xml", transactionInfo.AppName,
                        transactionInfo.TransName, transactionInfo.TransId, transactionInfo.Venders.Replace(':', '$'),
                        transactionInfo.RetryCount);
                    var strLogFolder = string.Format(loglocation, transactionInfo.TransName);
                    if (!Directory.Exists(strLogFolder))
                    {
                        throw new Exception("Counld not find the path " + strLogFolder);
                    }

                    if (!isError)
                    {
                        var date = DateTime.Now.Date;
                        var dateFolder = string.Format("{0}{1}{2}", date.Year, date.Month, date.Day);
                        strLogFolder = Path.Combine(strLogFolder, dateFolder);
                        if (!Directory.Exists(strLogFolder))
                        {
                            Directory.CreateDirectory(strLogFolder);
                        }
                    }
                    File.WriteAllBytes(Path.Combine(strLogFolder, fileName), payloadBytes);
                }
                return true;
            }
            catch (Exception exception)
            {
                ErrorLog.LogMessage(strComponent, 3, string.Format("Not able to log file. {0}", exception.Message),
                    string.Empty, transactionInfo.AppName, transactionInfo.TransName, transactionInfo.TransId, 0);
                return false;
            }

        }

        public string FormatErrorMessage(string pMessage, bool pincludeComponent)
        {
            StackTrace st = new StackTrace();
            StackFrame sf = st.GetFrame(1);
            StringBuilder sb = new StringBuilder();
            sb.Append("Error in ").Append(sf.GetMethod().Name).Append(" method of ").Append(GetClassName());
            if (pincludeComponent)
            {
                sb.Append(" class of ").Append(strComponent).Append(" component. ");
            }
            else
            {
                sb.Append(" class ");
            }

            sb.Append(string.Empty).Append(pMessage);
            return sb.ToString();
        }

        public string GetClassName()
        {
            return this.GetType().Name;
        }

        public string CreateResponse(bool isSuccess, string strMessage, int responseCode)
        {
            StringBuilder sbDoc = new StringBuilder();
            sbDoc.Append("<Response>");
            sbDoc.Append("      <Source>iServer</Source>");

            sbDoc.Append(string.Format("      <{0}>{1}</{0}>", "AppName", transactionInfo.AppName));
            sbDoc.Append(string.Format("      <{0}>{1}</{0}>", "TransName", transactionInfo.TransName));
            sbDoc.Append(string.Format("      <{0}>{1}</{0}>", "TransId", transactionInfo.TransId));

            if (isSuccess)
            {
                sbDoc.Append("      <Success>True</Success>");
            }
            else
            {
                sbDoc.Append("      <Success>False</Success>");
                sbDoc.Append("      <Error>");
                sbDoc.Append("               <ErrorMessage>" + strMessage + "</ErrorMessage>");
                sbDoc.Append("               <ErrorCode>" + responseCode + "</ErrorCode>");
                sbDoc.Append("      </Error>");
            }
            sbDoc.Append("</Response>");
            return sbDoc.ToString();
        }
    }
}