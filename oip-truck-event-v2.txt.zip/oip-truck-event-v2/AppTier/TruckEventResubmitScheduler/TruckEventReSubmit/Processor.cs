﻿using CDK.Data.OIP.API;
using HttpRequestProcessor;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;

namespace TruckEventReSubmit
{
    public class Processor
    {
        private ConfigurationDetails configurationDetails;
        private string componentName = "Scheduler";
        public Processor()
        {
            configurationDetails=new ConfigurationDetails();
        }
        public Processor(ConfigurationDetails configuration)
        {
            configurationDetails = configuration;
        }
        public void ProcessFiles()
        {
            try
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(configurationDetails.FailedToPublishPath);
                if (!directoryInfo.Exists)
                {
                    throw new Exception("Folder does not exists");
                }
                // do need to set order
                var Files = directoryInfo.EnumerateFiles().Take(configurationDetails.BatchCount);//.Select(a=>new {Name=a.Name,FullName=a.FullName});
                var fileNames=new List<string>();
                foreach (var file in Files)
                {
                    var newPath = Path.Combine(configurationDetails.InProgressPath, file.Name);
                    file.MoveTo(newPath);
                    fileNames.Add(newPath);
                }
                //directoryInfo = new DirectoryInfo(configurationDetails.InProgressPath);
                //Files = directoryInfo.EnumerateFiles().Take(configurationDetails.BatchCount);
                foreach (var filename in fileNames)
                {
                    var file=new FileInfo(filename);
                    if (!file.Exists)
                    {
                        throw new Exception("File Does not exists.");
                    }
                    var transaction = new TransactionDetails();
                    try
                    {
                        var fileName = file.Name;
                        var parameters = fileName.Split('~');
                        if (parameters.Length < 4)
                        {
                            throw new Exception("FileName not correct.");
                        }
                        
                        transaction.AppName = parameters.First();
                        transaction.TransName = parameters[1];
                        transaction.TransId = parameters[2];
                        transaction.Venders = parameters[3].Replace('$', ':');
                        transaction.RetryCount = Convert.ToInt32(parameters.Last().Replace(".xml",string.Empty));
                        if (transaction.RetryCount > configurationDetails.RetryCount)
                        {
                            throw new Exception("Maximun number of Retry reached.");
                        }
                        if (string.IsNullOrEmpty(transaction.AppName) || string.IsNullOrEmpty(transaction.TransName) ||
                            string.IsNullOrEmpty(transaction.TransId) || string.IsNullOrEmpty(transaction.Venders))
                        {
                            throw new Exception("Parameters are not present.");
                        }
                        var dataset = new DataSet();
                        int recordCount = 0;
                        var filecontent = CDK.Data.OIP.GenericUtility.FileSystemUtility.ReadFromFile(file.FullName);
                        TimePoints.GetTransactionInfo(transaction.TransId, ref dataset, ref recordCount);
                        if (dataset.CheckDataSetIfEmpty())
                        {
                            SendRequestToHandler(transaction, filecontent);
                            file.MoveTo(Path.Combine(configurationDetails.ArchiveLocation, file.Name));
                            continue;
                        }
                        dataset.Dispose();
                        dataset = new DataSet();
                        ServerAPIHelper serverApiHelper = new ServerAPIHelper(transaction);
                        Conversation.GetConversations(transaction.AppName, transaction.TransId, null, null, ref dataset);
                        //
                        if (dataset.CheckDataSetIfEmpty())
                        {
                            serverApiHelper.CreateConversation();
                        }
                        transaction.GenerateVenderDetails();
                        //dataset = new DataSet();
                        // get all transactions in the conversation
                        //Conversation.GetTransactionsByConversation(transaction.AppName, transaction.TransId, null, null, ref dataset);
                        
                        foreach (var vender in transaction.VendersDictionary)
                        {
                            vender.TransId = Guid.NewGuid().ToString();
                            dataset.Dispose();
                            dataset = new DataSet();
                            Conversation.GetTransactionsByConversation(vender.AppName, transaction.TransId, null, null, ref dataset);
                            if (dataset.CheckDataSetIfEmpty())
                            {
                                serverApiHelper.AddTransactionInConversation(vender);
                            }
                            else
                            {
                                vender.TransId = dataset.Tables[0].Rows[0]["TransID"].ToString();
                            }
                        }
                        dataset.Dispose();
                        byte[] payload =Encoding.ASCII.GetBytes(filecontent);

                        serverApiHelper.SendMesageWithTP(configurationDetails.GetSpecificParameter(transaction.TransName), payload);
                        file.MoveTo(Path.Combine(configurationDetails.ArchiveLocation,file.Name));
                    }
                    catch (Exception exception)
                    {
                        // what we need to do with file
                        ErrorLog.LogMessage(componentName, 3, exception.ToLogError(string.Empty), string.Empty,
                            transaction.AppName, transaction.TransName, transaction.TransId, 0);
                        MoveWithRetryIncrement(file);
                        //file.MoveTo(Path.Combine(configurationDetails.ErrorLocation,file.Name));
                    }
                    
                }
                
            }
            catch (Exception exception)
            {
                ErrorLog.LogMessage(componentName, 3, exception.ToLogError(String.Empty), String.Empty,
                    configurationDetails.AppName, configurationDetails.TransType,Guid.NewGuid().ToString(),0);
            }
        }

        public void MoveWithRetryIncrement(FileInfo file)
        {
            var retryCount = Convert.ToInt32(file.Name.Substring(file.Name.Length - 5, 1)) +1;
            var newFileName = file.Name.Substring(0, file.Name.Length - 5) + retryCount + ".xml";
            if (retryCount > configurationDetails.RetryCount)
            {
                file.MoveTo(Path.Combine(configurationDetails.ErrorLocation, file.Name));
            }
            else
            {
                file.MoveTo(Path.Combine(configurationDetails.FailedToPublishPath, newFileName));    
            }
            

        }

        public bool SendRequestToHandler(TransactionDetails transDetails,string content)
        {
            try
            {
                var querystring = string.Format("AppName={0}" +
                                                "&TransID={1}" +
                                                "&TransName={2}" +
                                                "&Business=truck" +
                                                "&RetryCount={3}", transDetails.AppName, transDetails.TransId, transDetails.TransName,transDetails.RetryCount);
                using (var httpClient = new HttpClient())
                using (var httpContent = new StringContent(content))
                {
                    httpClient.DefaultRequestHeaders.Add("venders", transDetails.Venders);
                    httpClient.PostAsync(string.Format("{0}?{1}", configurationDetails.HandlerUrl, querystring), httpContent);
                }
                
            }
            catch (Exception exception)
            {
                throw new Exception("Error while sending request to Handler.",exception);
            }
            return true;


        }
    }
}
