﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace PostToPartnerGenericProvider
{
    public class CommonProviderConfiguration : ConfigurationSection
    {
        [ConfigurationProperty("providers")]
        public ProviderSettingsCollection Providers
        {
            get
            {
                return (ProviderSettingsCollection)base["providers"];
            }
        }

        [ConfigurationProperty("default", DefaultValue = "Unknown")]
        public string DefaultTransType
        {
            get
            {
                return (string)base["default"];
            }
            set
            {
                base["default"] = value;
            }
        }
    }
}
