# TruckEvent


## Getting Started 


##**Where To Find The TruckEvent Components**
**Source:** http://stash.cdk.com/projects/OIP/repos/truckevent/browse

**Documentation:** https://confluence.cdk.com/display/DCOE/OIP+-+TruckEvent