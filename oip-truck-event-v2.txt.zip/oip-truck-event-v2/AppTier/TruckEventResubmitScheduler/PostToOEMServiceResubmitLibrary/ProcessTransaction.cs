﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using HttpRequestProcessor;
using CDK.Data.OIP.API;
using CDK.Data.OIP.GenericUtility;

namespace PostToOEMServiceResubmitLibrary
{
    public class ProcessTransaction
    {
        /// <summary>
        /// ProcessMessage
        /// </summary>
        /// <param name="strAppName"></param>
        public void ProcessMessage(string strAppName)
        {
            string strTransName = string.Empty;
            string strConversationId = string.Empty;
            string strConversationAppName = string.Empty;
            string strTransId = string.Empty;
            string strActivationId = string.Empty;
            string strVenders = string.Empty;
            string[] strRetryFileInfo = null;
            string strRetryCount = string.Empty;
            string strFailedToPostToPartnerDir = string.Empty;
            string strInProcessDir = string.Empty;
            string strArchiveDir = string.Empty;
            string strErrorDir = string.Empty;
            string strFileName = string.Empty;
            string strExchangeName = string.Empty;
            string strResponse = string.Empty;
            string strRoEventLogIncoming = string.Empty;
            int intRetryLimit=0;
            int intRetryCount = 0;
            int nCouont = 0;
            DataSet ds = new DataSet();
            bool hasConversationid = false;
            bool hasTransactionId = false;

            try
            {
                intRetryLimit = int.Parse(ConfigurationManager.AppSettings["RetryLimit"]);
                strFailedToPostToPartnerDir = string.Format(ConfigurationManager.AppSettings["LogFailedToPostToPartner"], strAppName);
                strErrorDir = string.Format(ConfigurationManager.AppSettings["LogErrorPath"], strAppName);
                strInProcessDir = string.Format(ConfigurationManager.AppSettings["LogInProcess"], strAppName);
                strArchiveDir = string.Format(ConfigurationManager.AppSettings["LogArchive"], strAppName);
               

                ArrayList arrFileList = GetFilesList(strFailedToPostToPartnerDir, "*.XML");

                foreach (FileInfo fl in arrFileList)
                {
                    MoveFile(fl.Name, strFailedToPostToPartnerDir, strInProcessDir, true);
                }

                foreach (FileInfo fl in arrFileList)
                {
                    strFileName = fl.Name;
                    strRetryFileInfo = null;
                    strRetryFileInfo = strFileName.Split('~');
                    if (strRetryFileInfo != null && strRetryFileInfo.Length > 0)
                    {
                        strAppName = strRetryFileInfo[0].ToString();
                        strTransName = strRetryFileInfo[1].ToString();
                        strConversationId = strRetryFileInfo[2].ToString();
                        strConversationAppName = strRetryFileInfo[3].ToString();
                        strTransId = strRetryFileInfo[4].ToString();
                        strActivationId = strRetryFileInfo[5].ToString();
                        strVenders = strRetryFileInfo[6].ToString();
                        strRetryCount = strRetryFileInfo[7].ToString();
                        if (strRetryCount != string.Empty)
                            intRetryCount = int.Parse(strRetryCount.Split('.')[0].ToString());
                        intRetryCount++;

                        if (intRetryCount <= intRetryLimit)
                        {
                            if (strConversationId != string.Empty)
                            {
                                ds = new DataSet();
                                nCouont = 0;
                                TimePoints.GetTransactionInfo(strConversationId, ref ds, ref nCouont);
                                if (ds.Tables.Count > 0)
                                {
                                    hasConversationid = true;
                                }
                            }
                            if (strTransId != string.Empty && hasConversationid == true)
                            {
                                ds = new DataSet();
                                nCouont = 0;
                                TimePoints.GetTransactionInfo(strTransId, ref ds, ref nCouont);
                                if (ds.Tables.Count > 0)
                                {
                                    hasTransactionId = true;
                                }
                            }

                            if (hasTransactionId == true && hasConversationid == true)
                            {
                                Dictionary<string, string> disParams = new Dictionary<string, string>();
                                disParams.Add("AppName", strAppName);
                                disParams.Add("TransName", strTransName);
                                disParams.Add("ConversationId", strConversationId);
                                disParams.Add("ConversationAppName", strConversationAppName);
                                disParams.Add("TransId", strTransId);
                                disParams.Add("ActivationId", strActivationId);
                                disParams.Add("Venders", string.Format("{0}:{1}", strAppName, strActivationId));
                                disParams.Add("RetryCount", intRetryCount.ToString());

                                int iExists = Routing.GetProperty(strAppName, "RoEventLogIncoming", ref strRoEventLogIncoming, Convert.ToInt32(strActivationId));
                                if (!iExists.Equals(0))
                                {
                                    throw new Exception("Unable to retrieve RoEventLogIncoming property value from OIP Database. Please check under application " + strAppName + " the value for RoEventLogIncoming property.");
                                }


                                //TimePoints.UpdateExtraCriteria(strAppName, strTransId, "RetryCount:" + intRetryCount);
                                var payLoad = CDK.Data.OIP.GenericUtility.FileSystemUtility.ReadBytesFromFile(Path.Combine(strInProcessDir, strFileName));
                                //var payLoad = GenericUtility.FileSystemUtility.ReadFromFile(Path.Combine(strInProcessDir, strFileName));
                                SaveMessage(payLoad, disParams);
                                //var transaction = new TransactionDetails();
                                //transaction.AppName = strConversationAppName;
                                //transaction.TransName = strTransName;
                                //transaction.TransId = strConversationId;
                                //transaction.VendersDictionary.Add(new VendersDetails(){ ActivationId = strActivationId,AppName = strAppName,TransId = strTransId});
                                //transaction.RetryCount = intRetryCount;
                                //transaction.Venders = string.Format("{0}:{1}", strAppName,strActivationId);

                                //strExchangeName = ConfigurationManager.AppSettings[strTransName];


                                //ServerAPIHelper serverApiHelper = new ServerAPIHelper(transaction);
                                //serverApiHelper.SendMesageWithTP(strExchangeName, payLoad);

                                //ToOEMService.ProcessTransactionClient client = new ToOEMService.ProcessTransactionClient();
                                //client.ProcessMessage(payLoad, disParams);

                                //Post transactions to OEM Begin
                                //CommonProviderManager providerMgr = new CommonProviderManager();
                                //providerMgr.ExecuteProvider(strAppName.ToUpper());
                                //strResponse = providerMgr.Provider.PostMessageToPartner(payLoad, disParams);
                                ////Post transactions to OEM End

                                //if (!string.IsNullOrEmpty(strResponse))
                                //{
                                //    //Log TimePoint4 completed Begin
                                //    bResult = Convert.ToBoolean(TimePoints.MarkNext(strAppName, strTransId, 4, "Completed"));
                                //    if (!bResult)
                                //    {
                                //        throw new Exception("Failed to mark fourth time point for Activation:" + strActivationId);
                                //    }
                                //    //Log TimePoint4 completed Begin
                                //}

                                MoveFile(strFileName, strInProcessDir, strArchiveDir, true);
                            }
                        }
                        else
                        {
                            MoveFile(strFileName, strInProcessDir, strErrorDir, true);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string strError = ex.Message.ToString();
                ErrorLog.LogMessage("PostToOEMServiceResubmitLibrary", 3, strError, "", strAppName, strTransName, strTransId, strActivationId);
                string fileName = string.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}.xml", strAppName, strTransName, strConversationId, strConversationAppName, strTransId, strActivationId, strVenders, intRetryCount);
                MoveFile(strFileName, strFailedToPostToPartnerDir, strInProcessDir,fileName,true);
            }
        }

        public void SaveMessage(byte[] payloadBytes, Dictionary<string, string> disParams)
        {
            try
            {
                //changed code to write into filedep

                var venders = disParams["Venders"].Split(',');
                string savePayloads = ConfigurationManager.AppSettings["SavePayloads"];
                foreach (string vender in venders)
                {
                    if (!string.IsNullOrWhiteSpace(vender))
                    {
                        var transInfo = vender.Split(':');
                        if (!string.IsNullOrWhiteSpace(transInfo[0]))
                        {
                            savePayloads = String.Format(savePayloads, transInfo[0]);

                            string fileName = transInfo[0] + "~" + transInfo[1] + "~" + disParams["ConversationId"] + "~" + disParams["TransId"] + "~"+ disParams["TransName"] + "~"+ disParams["RetryCount"] + ".xml";

                            FileSystemUtility.WriteToFile(savePayloads + "\\" + fileName, System.Text.Encoding.UTF8.GetString(payloadBytes));
                        }
                    }

                }
            }
            catch (Exception exception)
            {
                var errorMessage = "Error writing the file.";
                throw new Exception(errorMessage, exception);
            }
        }

        /// <summary>
        /// GetFilesList
        /// </summary>
        /// <param name="source"></param>
        /// <param name="pattern"></param>
        /// <returns></returns>
        private ArrayList GetFilesList(string source, string pattern)
        {

            ArrayList fileList = new ArrayList();
            System.IO.DirectoryInfo dirInfo = new DirectoryInfo(source);
            System.IO.FileInfo[] fileInfo;

            try
            {

                int nBatchCount = Convert.ToInt32(ConfigurationManager.AppSettings["BatchCount"].ToString());

                fileInfo = dirInfo.GetFiles(pattern);

                foreach (FileInfo file in fileInfo)
                {
                    fileList.Add(file);

                    if (fileList.Count == nBatchCount)
                        break;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(" Error in GetFilesList method. " + ex.Message);
            }

            return fileList;

        }

        /// <summary>
        /// MoveFile
        /// </summary>
        /// <param name="Filename"></param>
        /// <param name="Source"></param>
        /// <param name="Destination"></param>
        /// <param name="OverWrite"></param>
        private void MoveFile(string Filename, string Source, string Destination, bool OverWrite)
        {
            try
            {
                File.Copy(Path.Combine(Source, Filename), Path.Combine(Destination, Filename), OverWrite);

                File.Delete(Path.Combine(Source, Filename));

            }
            catch (Exception ex)
            {
                throw new Exception("Error in MoveFile method. " + ex.Message);
            }
        }

        /// <summary>
        /// MoveFile
        /// </summary>
        /// <param name="Filename"></param>
        /// <param name="Source"></param>
        /// <param name="Destination"></param>
        /// <param name="DestinationFileName"></param>
        /// <param name="OverWrite"></param>
        private void MoveFile(string Filename, string Source, string Destination,string DestinationFileName, bool OverWrite)
        {
            try
            {
                File.Copy(Path.Combine(Source, Filename), Path.Combine(Destination, DestinationFileName), OverWrite);

                File.Delete(Path.Combine(Source, Filename));

            }
            catch (Exception ex)
            {
                throw new Exception("Error in MoveFile method. " + ex.Message);
            }
        }
    }
}
