﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using System.Web.Configuration;

namespace PostToPartnerGenericProvider
{
    public class CommonProviderManager
    {

        private CommonAbstractProvider currentProvider;
        private CommonProviderCollection providers;
        private string _AppType;
        private object _lockProvider = new object();

        public void ExecuteProvider(string AppType)
        {
            if (string.IsNullOrEmpty(_AppType) || AppType.ToUpper() != _AppType.ToUpper())
            {
                _AppType = AppType;
                Initialize();
            }
        }

        private void Initialize()
        {

            CommonProviderConfiguration configuration =
                (CommonProviderConfiguration)ConfigurationManager.GetSection("CommonProviders");

            if (configuration == null)
                throw new ConfigurationErrorsException("CommonProviders configuration must be set properly. Please check the App.config file.");

            providers = new CommonProviderCollection();

            ProvidersHelper.InstantiateProviders(configuration.Providers, providers, typeof(CommonAbstractProvider));

            providers.SetReadOnly();

            currentProvider = providers[_AppType];

            if (currentProvider == null)
                throw new Exception("The DCS common provider " + _AppType + " does not exist");

        }

        public CommonAbstractProvider Provider
        {
            get
            {
                return currentProvider;
            }
        }

        public CommonProviderCollection Providers
        {
            get
            {
                return providers;
            }
        }
    }
}
