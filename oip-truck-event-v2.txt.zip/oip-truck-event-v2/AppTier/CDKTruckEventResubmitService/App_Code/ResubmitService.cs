﻿using CDK.Data.OIP.API;
using System;
using System.Configuration;
using System.Data;
using System.IO;
using System.Web.Services;

namespace CDKTruckEventResubmitService
{
    /// <summary>
    /// Summary description for ResubmitService
    /// </summary>
    [WebService(Namespace = "http://iServer.DealerServices.ADP.com/Resubmit")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class ResubmitService : System.Web.Services.WebService
    {

        //public ResubmitService()
        //{

        //    //Uncomment the following line if using designed components 
        //    //InitializeComponent(); 
        //}

        //[WebMethod]
        //public string HelloWorld()
        //{
        //    return "Hello World";
        //}
        public string category = "Resubmit";
        public string component = "CDKTruckEventResubmit";
        public string _ApplicationName = "TruckEvent";

        //[WebMethod]
        //public string HelloWorld()
        //{
        //    return "Hello World";
        //}

        /// <summary>
        /// Method to Resubmit failed transactions.
        /// </summary>
        /// <param name="sTransId">Transaction ID</param>
        /// <param name="sAppName">Application Name</param>
        /// <param name="sTransType">Transaction Type</param>
        /// <param name="sTransStatus">Transaction Status</param>
        /// <param name="sDlrCode">Dealer code</param>
        /// <param name="sActivationId">Activation ID</param>
        /// <returns>0 :Success, -1 :Failure</returns>
        [WebMethod(Description = "Resubmit Interface for TruckEvent Application")]
        public int Resubmit(string sTransId, string sAppName, string sTransType, string sTransStatus, string sDlrCode, string sActivationId)
        {
            int nReturn = -1;
            string strExtra2 = string.Empty;
            DataSet transDS = null;
            int nCount = 0;
            try
            {
                #region Retrive transaction info.
                TimePoints.GetTransactionInfo(sTransId, ref transDS, ref nCount);

                if (transDS != null && transDS.Tables[0].Rows.Count > 0)
                {
                    strExtra2 = transDS.Tables[0].Rows[0]["ExtraCriteria"].ToString(); //File name

                }
                else
                {
                    throw new Exception("Could not retrieve Transaction Info.");

                }
                #endregion

                if (checkTransactionResubmittable(sTransType))
                {
                    nReturn = ProcessTransaction(strExtra2, sDlrCode, sTransType, sTransId, sTransStatus, sAppName);
                }

            }
            catch (Exception ex)
            {
                nReturn = -1;
                ErrorLog.LogMessage(component, 3, ex.Message, category, _ApplicationName, sTransType, sTransId, sDlrCode);
            }

            return nReturn;

        }

        public int ProcessTransaction(string strFilename, string strDlrCode, string strTransType, string strTransID, string strStatus, string strAppName)
        {
            int iProcessFlag = -1;
            string FailedToPostToPartnerLoc = string.Empty;
            string NotSupportedStatuses = string.Empty;
            bool bResubmit = true;
            //bool CheckAllFolders = Convert.ToBoolean(ConfigurationManager.AppSettings["CheckAllFolders"].ToString());
            if (strAppName.ToUpper() == "DECISIVSRM")
            {
                FailedToPostToPartnerLoc = string.Format(ConfigurationManager.AppSettings["LogErrorPath"], strAppName);
                NotSupportedStatuses = ConfigurationManager.AppSettings["StatusesNotSupportedForDecisivResubmit"];
            }
            else if (strAppName.ToUpper() == "TRUCKEVENT")
            { 
                FailedToPostToPartnerLoc = string.Format(ConfigurationManager.AppSettings["LogTEErrorPath"], strAppName);
                NotSupportedStatuses = ConfigurationManager.AppSettings["StatusesNotSupportedForTEResubmit"];
            }
            
            try
            {
                bResubmit = CheckTransactionStatus(strStatus, NotSupportedStatuses);

                if (!bResubmit)
                {
                    throw new Exception("Transaction with '" + strStatus + "' status can not be re-submitted.");
                }

                string Location = string.Empty;
                //if (CheckAllFolders)
                //{
                //    Location = ConfigurationManager.AppSettings["TruckEventRootLoc"];
                //}
                //else
                {
                    Location = FailedToPostToPartnerLoc;
                }
                System.IO.FileInfo objFileInfo = GetFile(strTransID, Location);
                iProcessFlag = ResubmitProcess(objFileInfo, strTransID, strAppName);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return iProcessFlag;
        }


        private int ResubmitProcess(FileInfo RetryFile, string TransID, string srAppName)
        {
            int iSuccess = -1;
            string RetryLocation = string.Empty;
            string FileExtension = Path.GetExtension(RetryFile.Name);
            string strNewFilename = string.Empty;
            string direction = string.Empty;
            string strAppName = string.Empty;
            string strTransName = string.Empty;
            string strConversationId = string.Empty;
            string strConversationAppName = string.Empty;
            string strTransId = string.Empty;
            string strActivationId = string.Empty;
            string strVenders = string.Empty;
            string strStatus = string.Empty;
            int intRetryCount = 0;

            string[] TempFileName = RetryFile.Name.Split('~');
            try
            {
                if (srAppName.ToUpper() == "DECISIVSRM")
                {
                    RetryLocation = string.Format(ConfigurationManager.AppSettings["LogFailedToPostToPartner"], srAppName);
                    strAppName = TempFileName[0].ToString();
                    strTransName = TempFileName[1].ToString();
                    strConversationId = TempFileName[2].ToString();
                    strConversationAppName = TempFileName[3].ToString();
                    strTransId = TempFileName[4].ToString();
                    strActivationId = TempFileName[5].ToString();
                    strVenders = TempFileName[6].ToString();
                    intRetryCount = 0;
                    strNewFilename = string.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}.xml", strAppName, strTransName, strConversationId, strConversationAppName, strTransId, strActivationId, strVenders, intRetryCount);
                }
                else if (srAppName.ToUpper() == "TRUCKEVENT")
                {
                    RetryLocation = string.Format(ConfigurationManager.AppSettings["LogTEFailedToPostToPartner"], srAppName);

                    strAppName = TempFileName[0].ToString();
                    strTransName = TempFileName[1].ToString();
                    strTransId = TempFileName[2].ToString();
                    strVenders = TempFileName[3].ToString();
                    strStatus = TempFileName[4].ToString();
                    intRetryCount = 0;
                    strNewFilename = string.Format("{0}~{1}~{2}~{3}~{4}~{5}.xml", strAppName, strTransName, strTransId, strVenders, strStatus,intRetryCount);
                }
                string strDestinationFile = Path.Combine(RetryLocation, strNewFilename);
                if (MoveFile(RetryFile.FullName, strDestinationFile, true))
                {
                    TimePoints.UpdateTransStatus(strAppName, TransID, "Re-queued");
                }
                iSuccess = 0;

            }
            catch (Exception ex)
            {

                iSuccess = -1;
                throw new Exception(ex.Message);
            }
            return iSuccess;
        }

        /// <summary>
        /// Method to move a file from a source location to a destination location allowing to overwrite
        /// </summary>
        /// <param name="SourceFile"></param>
        /// <param name="DestinationFile"></param>
        /// <param name="Overwrite"></param>
        private bool MoveFile(string SourceFile, string DestinationFile, bool Overwrite)
        {
            bool flag = false;
            try
            {
                File.Copy(SourceFile, DestinationFile, Overwrite);
                if (File.Exists(SourceFile))
                {
                    File.Delete(SourceFile);
                }

                flag = true;

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return flag;
        }

        private static System.IO.FileInfo GetFile(string sTransId, string Location)
        {
            if (!Directory.Exists(Location))
                throw new Exception(string.Format("Failed Files location {0} does not exist", Location));

            System.IO.DirectoryInfo objDirInfo = new System.IO.DirectoryInfo(Location);
            System.IO.FileInfo[] objGetFileInfo;

            objGetFileInfo = objDirInfo.GetFiles(string.Concat("*", sTransId, "*"), System.IO.SearchOption.AllDirectories);

            if (objGetFileInfo.Length == 0)

                throw new Exception(string.Format("Failed to locate file with trans ID {0} in {1} location", sTransId, Location));

            else
                return objGetFileInfo[0];


        }

        private bool CheckTransactionStatus(string strTransactionStatus, string NotSupportedStatuses)
        {
            bool resubmit = true;
            string[] NotSupportedStatusesValues = NotSupportedStatuses.Split(',');

            foreach (string status in NotSupportedStatusesValues)
            {
                if (status.Equals(strTransactionStatus, StringComparison.OrdinalIgnoreCase))
                {
                    resubmit = false;
                    break;
                }
            }
            return resubmit;
        }

        private bool checkTransactionResubmittable(string sTransType)
        {
            string transNames = ConfigurationManager.AppSettings["ResubmittableTransactionNames"].ToString();
            string[] transactions = transNames.Split(',');
            bool bTransExist = false;
            foreach (string trans in transactions)
            {
                if (trans.Equals(sTransType, StringComparison.OrdinalIgnoreCase))
                {
                    bTransExist = true;
                    break;

                }
            }
            if (!bTransExist) throw new Exception("Transaction type '" + sTransType + "' not supported."); // throw new Exception();

            return bTransExist;
        }
    }
}