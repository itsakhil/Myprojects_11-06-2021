﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration.Provider;

namespace PostToPartnerGenericProvider
{
    public class CommonProviderCollection : ProviderCollection
    {
        new public CommonAbstractProvider this[string name]
        {
            get { return (CommonAbstractProvider)base[name]; }
        }
    }
}
