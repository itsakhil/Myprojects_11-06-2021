﻿var urlParser = require('url');
var querystringbuilder = require('querystring');
var http = require('http');
var config = require('config');
var port = process.env.port || 1338;

var appsettings;
var configSetttings;
if (config.has('Configuration.AppSettings')) {
    appsettings= {};
    configSetttings = config.get('Configuration.AppSettings');
   // appsettings = appsettings.makeImmutable();
    appsettings.port = process.env["port"] == undefined ? configSetttings.port : process.env["port"];
    appsettings.AppName = process.env["AppName"] == undefined ? configSetttings.AppName : process.env["AppName"];
    appsettings.MaxRequestLength = process.env["MaxRequestLength"] == undefined ? configSetttings.MaxRequestLength : process.env["MaxRequestLength"];
    appsettings.DealorCode = process.env["DealorCode"] == undefined ? configSetttings.DealorCode : process.env["DealorCode"];
    appsettings.VendorsList = process.env["VendorsList"] == undefined ? configSetttings.VendorsList : process.env["VendorsList"];
    appsettings.HandlerURL = process.env["HandlerURL"] == undefined ? configSetttings.HandlerURL : process.env["HandlerURL"];
    appsettings.TransactionName = process.env["TransactionName"] == undefined ? configSetttings.TransactionName : process.env["TransactionName"];
    //console.log(appsettings);
    Object.freeze(appsettings);
    //console.log(appsettings);
}
var gobaldata = '';




var HandlerRequest = function (req, res) {
    var responseHeader = { 'Content-Type': 'application/xml' };
    //var responseHeader = { 'Content-Type': 'application/xml', 'Connection': 'Close' };
    if (req.method == 'POST') {
        //var headers = JSON.stringify(req.headers);
       
        var values = {};
        var url_parts = urlParser.parse(req.url, true).query;
        try {


            
            values.AppName = url_parts.Application != undefined ? url_parts.Application : '';
            values.TransName = url_parts.TransName != undefined ? url_parts.TransName : '';
            values.TransID = url_parts.TransID != undefined ? url_parts.TransID : '';

            if (ValidateRequest(req, function(result, message) {
                console.log("validation failed");
                res.writeHead(200, "OK", responseHeader);
                res.end(CreateResponse(values, result, message, 1201));
            })) {
                var venders = req.headers['vendorslist'].split(',');
                var venderString = req.headers['vendorslist'];

                console.log(venders);
                //console.log(url_parts);
                var routings = [];
                var activationId = {};
                for (i = 0; i < venders.length; i++) {
                    var vendorName = venders[i].split(':');
                    if (vendorName.length == 2) {
                        routings.push(vendorName[0]);
                        activationId[vendorName[0]] = vendorName[1];
                    } else {
                        console.log("validation failed");
                        res.writeHead(200, "OK", responseHeader);
                        res.end(CreateResponse(values, 'false', "vender string is not valid", 1201));
                        return;
                    }
                }

                var metadata = { TransactionName: url_parts.TransName, TransID: url_parts.TransID, AppName: url_parts.Application, venders: venderString, VendorsList: routings };

                var queryData = '';

                req.on('data', function(data) {
                    queryData += data;
                });

                req.on('end', function() {
                    //console.log(queryData);
                    gobaldata = queryData;
                    RouteMessage(gobaldata, metadata, function(error, success, response) {
                        if (success == 'true') {
                            res.writeHead(200, "OK", responseHeader);
                            res.end(response);
                        } else {
                            res.writeHead(500, " CDK - Internal Server Error", responseHeader);

                            console.log(CreateResponse(values, 'false', response, 1201));
                            var responsetest = CreateResponse(values, 'false', response, 1201);
                            res.end(responsetest);
                        }
                    });
                });
                console.log("Ok Status");
                //        res.writeHead(200, "OK", { 'Content-Type': 'text/html' });
                //      res.end('<html><head><title>200</title></head><body><h1>.</h1></body></html>');
                console.log("W");
            }
        } catch (e) {
            console.log("Error");
            console.log(e);
            res.writeHead(500, " CDK - Internal Server Error", responseHeader);
            var responsetest = CreateResponse(values, 'false', "Internal Error Occured", 1201);
            res.end(responsetest);
        }
    }
    else {
        console.log("Ok Status");
        res.writeHead(200, "OK", { 'Content-Type': 'text/html' });
        //res.end('<html><head><title>200 - Method not supported</title></head><body><h1>Method not supported.'+ process.env["AppName"]+ '.'+appsettings.AppName+'</h1></body></html>');
        res.end('<html><head><title>200 - Method not supported</title></head><body><h1>Method not supported.</h1></body></html>');
        //res.end();
        console.log("W");

        //console.log("[405] " + req.method + " to " + req.url);
        //res.writeHead(405, "Method not supported", { 'Content-Type': 'text/xml' });

    }

};

var ValidateRequest = function (req, validationResult) {
    var queryString = urlParser.parse(req.url, true).query;
    var venders = req.headers["vendorslist"];
    
    var result = false;
    
    if (checkQueryString(queryString, 'Application')) {
        validationResult("false", "Application not present in QueryString");
    }
    else if (checkQueryString(queryString, 'TransName')) {
        validationResult("false", "TransName not present in QueryString");
    }
    else if (checkQueryString(queryString, 'TransID')) {
        validationResult("false", "TransID not present in QueryString");
    }
    else if (queryString.Application.toUpperCase() != appsettings.AppName.toUpperCase()) {
        validationResult("false", "AppName not valid");
    }
    else if ( appsettings.TransactionName.toUpperCase().indexOf(','+queryString.TransName.toUpperCase()+',')==-1) {
        validationResult("false", "TransName not valid");
    }
    else if (venders == undefined || venders == null) {
        validationResult("false", "venders are not present in header.");
    }
    else if (venders != undefined || venders != null) {
        var vedorsList = venders.split(',');
        var keyVendorlist = appsettings.VendorsList;
        for (i = 0; i < vedorsList.length; i++) {
            var ven = vedorsList[i].split(':');
            if (keyVendorlist.toUpperCase().indexOf(ven[0].toUpperCase()) == -1)
                validationResult("false", "Invalid Vendors list");
            else result = true;
                
        }
    }
    else {
        result = true;
    }
    return result;
};

var CreateResponse = function (properties, result, message, errorcode) {
    var values = '';
    values = values + '<AppName>' + properties.AppName + '</AppName>';
    values = values + '<TransName>' + properties.TransName + '</TransName>';
    values = values + '<TransID>' + properties.TransID + '</TransID>';
    if (result == 'true') {
        values = values + '<Success>True</Success>';
    } else {
        values = values + '<Success>False</Success>';
        values = values + '<Error><ErrorMessage>' + message + '</ErrorMessage><ErrorCode>' + errorcode + '</ErrorCode></Error>';
    }
    var response = '<Response><Source>OIP</Source>' + values + '</Response>';
    return response;
};

var checkQueryString = function (query, item) {
    if (query[item] == undefined || query[item] == null || query[item] == '') {
        return true;
    }
    return false;
};

function RouteMessage(data, metadata, done) {
    
    try {
        var transMetadata = metadata;
        var urlInfo;
        
        urlInfo = urlParser.parse(appsettings.HandlerURL);
        
        
        var querystring = querystringbuilder.stringify({ AppName: transMetadata.AppName, TransName: transMetadata.TransactionName, TransID: transMetadata.TransID })
        
        var request = data;
        var post_options = {
            host: urlInfo.hostname,
            port: urlInfo.port,
            path: urlInfo.pathname + '?' + querystring,
            method: 'POST',
            headers: {
                'Content-Type': 'text/xml',
                'Content-Length': request.length,
                'Vendors': transMetadata.venders
                //'Accept': 'text/xml'
            }
        };
        
        // Set up the request
        var post_req = http.request(post_options, function (res) {
            res.setEncoding('utf8');
            var statusCode = res.statusCode;
            var responseData = '';
            res.on('data', function (chunk) {
                console.log('Response: ' + chunk);
                if (statusCode == '200')
                    done(null, "true", chunk);
                else
                    done(null, "false", chunk);
                responseData += chunk;
				
            });
            res.on('error', function (chunk) {
                console.log('Response: ' + chunk);
                done(null, "false", chunk);
                //responseData += chunk;
				
            });
            console.log(statusCode);
        });
        post_req.on('error', function (error) {
            console.log('Errro : ' + error);
            done(null, "false", error);
        });
        post_req.write(request);
        post_req.end();
       
    }
    catch (ex) { done(ex, "false", ex.message); }
}

http.createServer(HandlerRequest).listen(port);