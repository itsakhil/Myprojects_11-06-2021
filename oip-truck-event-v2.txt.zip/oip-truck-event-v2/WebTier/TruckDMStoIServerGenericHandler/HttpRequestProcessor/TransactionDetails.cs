﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HttpRequestProcessor
{
    public class TransactionDetails
    {
        public string AppName { get; set; }
        public string TransName { get; set; }
        public string TransId { get; set; }
        public string Venders { get; set; }
        public int RetryCount { get; set; }
        public List<VendersDetails> VendersDictionary { get; set; }

        public TransactionDetails()
        {
            VendersDictionary=new List<VendersDetails>();
        }

        public void GenerateVenderDetails()
        {
            foreach (var vender in Venders.Split(','))
            {
                var venderdetail = vender.Split(':');
                var appName = venderdetail.First();
                var activationId = venderdetail.Last();
                var transID = Guid.NewGuid().ToString();
                VendersDictionary.Add(new VendersDetails()
                {
                    AppName = appName,
                    ActivationId = activationId,
                    TransId =transID
                }); 
            }
        }

    }

    public class VendersDetails
    {
        public string AppName { get; set; }
        public string ActivationId { get; set; }
        public string TransId { get; set; }
    }
}