﻿using CDK.Data.OIP.API;
using ProcessTransactionsLibrary;
using System;
using System.Configuration;
using System.IO;
using System.Text;
using Truck.Common;

namespace TruckROSchedulerToOEM
{
    public class ProcessDecisiveMessage : IProcessMessage
    {
        public string AppName { set; get; }
    
        private readonly string _conversationAppName;
        private readonly string _logErroPath;
        private readonly ProcessTransaction _processTransaction;
        private string component = "DecisiveSRMROCloseScheduler";

        public ProcessDecisiveMessage(string appName)
        {
            AppName = appName;
            _conversationAppName = ConfigurationManager.AppSettings["ConversationAppName"];
            _logErroPath = string.Format(ConfigurationManager.AppSettings["LogErrorFilePath"], appName);
            _processTransaction = new ProcessTransaction();
        }

        public bool ProcessMessage(string fileName, string data)
        {
            MessageHelper messageHelper = new MessageHelper();
            try
            {
                var collection = messageHelper.GetDefaultProperties(fileName, AppName, _conversationAppName);
                if (!Directory.Exists(_logErroPath))
                {
                    ErrorLog.LogMessage(component, 3, "FileDep location is not accessible", string.Empty, AppName, messageHelper.TransName, messageHelper.TransId, 0);
                    return false;
                }

                TimePoints.UpdateTransStatus(AppName, collection["TransId"], "ReceivedFromQueue");
                
                _processTransaction.ProcessMessage(data, collection);
            }
            catch (Exception exception)
            {
                Int32.TryParse(messageHelper.ActivationID, out var activationid);
                
                TimePoints.UpdateTransStatus(AppName, messageHelper.TransId, "FailedInScheduler");
                
                ErrorLog.LogMessage(component, 3,
                    messageHelper.FormatErrorMessage(exception.ToString(), true), String.Empty, AppName
                    , messageHelper.TransName, messageHelper.TransId, activationid);
                
                var payloadByte = Encoding.ASCII.GetBytes(data);
                messageHelper.LogErrorinFile(_logErroPath, payloadByte, AppName);
                return false;
            }
            return true;
        }

    }
}
