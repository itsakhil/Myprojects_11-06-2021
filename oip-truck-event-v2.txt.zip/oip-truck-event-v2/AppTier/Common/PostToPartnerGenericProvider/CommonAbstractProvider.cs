﻿using System;
using System.Collections.Generic;
using System.Configuration.Provider;
using System.Text;

namespace PostToPartnerGenericProvider
{
    public abstract class CommonAbstractProvider : ProviderBase
    {
        public abstract string PostMessageToPartner(string payload, Dictionary<string, string> dictHeaders);
    }
}
