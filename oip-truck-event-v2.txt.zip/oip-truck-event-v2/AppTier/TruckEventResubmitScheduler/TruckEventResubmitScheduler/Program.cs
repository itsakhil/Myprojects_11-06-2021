﻿using CDK.Data.OIP.API;
using PostToOEMServiceResubmitLibrary;
using System;
using TruckEventReSubmit;

namespace TruckEventResubmitScheduler
{
    class Program
    {
        static void Main(string[] args)
        {

            string strVendor = string.Empty;
            string strPostTo = string.Empty;
            try
            {
                strVendor = args[0].ToString();
                strPostTo = args[1].ToString();

                if (strVendor != string.Empty && strPostTo != string.Empty)
                {
                    switch (strPostTo.ToUpper())
                    {
                        //case "TORABBITMQ":
                        //{
                        //    var processor = new Processor();
                        //    processor.ProcessFiles();
                        //}
                        //    break;
                        case "TOOEM":
                            {
                                ProcessTransaction pt = new ProcessTransaction();
                                pt.ProcessMessage(strVendor);
                                break;
                            }
                    }
                }
                else
                {
                    throw new Exception("Empty arguments provided to the scheduler.");
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogMessage("TruckEventResubmitScheduler", 2, ex.Message, strPostTo, "TruckEvent", "", System.Guid.NewGuid().ToString(), 0);
            }
        }
    }
}
