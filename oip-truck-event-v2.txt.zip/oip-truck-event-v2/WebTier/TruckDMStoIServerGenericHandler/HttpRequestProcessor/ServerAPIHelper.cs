﻿using CDK.Data.OIP.API;
using CDK.Data.OIP.GenericUtility;
using System;
using System.Configuration;

namespace HttpRequestProcessor
{
    public class ServerAPIHelper
    {
        private TransactionDetails transactionInfo;
        public ServerAPIHelper(TransactionDetails transactionDetails)
        {
            transactionInfo = transactionDetails;
        }

        public void UpdateTPWithChildTransStatus(string status,bool isError=false,string errorMessage=null)
        {
            TimePoints.UpdateTransStatus(transactionInfo.AppName, transactionInfo.TransId, status);
            foreach (var vender in transactionInfo.VendersDictionary)
            {
                TimePoints.UpdateTransStatus(vender.AppName, vender.TransId, status);
                if (isError)
                {
                    ErrorLog.LogMessage("ProcesssMessage", 3, errorMessage, string.Empty, vender.AppName,
                        transactionInfo.TransName, vender.TransId, Convert.ToInt32(vender.ActivationId));
                }
            }
        }

        public bool AddTransactionInConversation(VendersDetails vender)
        {
            TimePoints.MarkFirst(vender.AppName, transactionInfo.TransName, vender.TransId,
                      Convert.ToInt32(vender.ActivationId), "Initiated", transactionInfo.TransId, string.Empty, 1);
            var result = Conversation.ConversationAddTransaction(transactionInfo.TransId, vender.AppName, vender.TransId);
            Conversation.TransactionExtraPropCreate(vender.AppName, vender.TransId, "Open", "Initiated", 0);
            if (result < 0)
            {
                throw new Exception("Failed to add transaction for conversation Vendor:" + vender.AppName);
            }
            return true;
        }

        public void CreateConversation()
        {
            var iresult = Conversation.ConversationCreate(transactionInfo.AppName, transactionInfo.TransId, "Open",
                    "Initiated", transactionInfo.TransId, 0);

            //Conversation.ConversationAddTransaction(transactionInfo.TransId, transactionInfo.AppName, transactionInfo.TransId);
            Conversation.TransactionExtraPropCreate(transactionInfo.AppName, transactionInfo.TransId, "Open", "Initiated", 0);
            if (iresult < 0)
            {
                throw new Exception("Failed to create a Conversation.");
            }
        }

        public void SendMesageWithTP(string exchangeName, byte[] payloadBytes)
        {
            try
            {
               
                foreach (var vender in transactionInfo.VendersDictionary)
                {
                    if (!string.IsNullOrWhiteSpace(vender.AppName))
                    {
                            string savePayloads = ConfigurationManager.AppSettings["SavePayloads"];
                            savePayloads = String.Format(savePayloads, vender.AppName);

                            string fileName = vender.AppName + "~" + vender.ActivationId + "~" + transactionInfo.TransId + "~" + vender.TransId + "~" +transactionInfo.TransName + "~0" + ".xml";

                            FileSystemUtility.WriteToFile(savePayloads + "\\" + fileName, System.Text.Encoding.UTF8.GetString(payloadBytes));
                    }
                }
            }
            catch (Exception exception)
            {
                var errorMessage = "Error writing the file.";
                throw new Exception(errorMessage, exception);
            }
        }
    }
}
