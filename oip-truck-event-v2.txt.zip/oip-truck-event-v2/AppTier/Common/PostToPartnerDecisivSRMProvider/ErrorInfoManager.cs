﻿using System;
using System.Configuration;
using System.Linq;
using System.Xml;

/// <summary>
/// Summary description for ErrorConfigManager
/// </summary>
namespace PostToPartnerDecisivSRMProvider
{
    public class ErrorTypesSection : ConfigurationSection
    {
        ErrorInfoElement errorInfoElement;
        public ErrorTypesSection()
        {
            errorInfoElement = new ErrorInfoElement();
        }

        [ConfigurationProperty("Info", IsDefaultCollection = false), ConfigurationCollection(typeof(ErrorTypeInfoCollection), AddItemName = "ErrorTypeInfo")]
        public ErrorTypeInfoCollection ErrorInfoManager
        {
            get
            {
                ErrorTypeInfoCollection errorTypeInfoCollection = (ErrorTypeInfoCollection)base["Info"];
                return errorTypeInfoCollection;
            }
        }
    }


    public class ErrorInfoElement : ConfigurationElement
    {
        public ErrorInfoElement(string id, string errCode, string errDesc, string logDescription, string category)
        {
            this.ID                 = id;
            this.ErrorCode          = errCode;
            this.ErrorDescription   = errDesc;
            this.LogDescription     = logDescription;
            this.Category           = category;
        }

        public ErrorInfoElement()
        {
        }

        [ConfigurationProperty("ID", IsRequired = true, IsKey = true)]
        public string ID
        {
            get { return (string)this["ID"]; }
            set { this["ID"] = value; }
        }

        [ConfigurationProperty("ErrorCode", IsRequired = true, IsKey = false)]
        public string ErrorCode
        {
            get { return (string)this["ErrorCode"]; }
            set { this["ErrorCode"] = value; }
        }

        [ConfigurationProperty("ErrorDescription", IsRequired = true)]
        public string ErrorDescription
        {
            get { return (string)this["ErrorDescription"]; }
            set { this["ErrorDescription"] = value; }
        }

        [ConfigurationProperty("LogDescription", IsRequired = false)]
        public string LogDescription
        {
            get { return (string)this["LogDescription"]; }
            set { this["LogDescription"] = value; }
        }

        [ConfigurationProperty("Category", IsRequired = true)]
        public string Category
        {
            get { return (string)this["Category"]; }
            set { this["Category"] = value; }
        }

    }


    public class ErrorTypeInfoCollection : ConfigurationElementCollection
    {
        public ErrorTypeInfoCollection()
        {
            ErrorInfoElement errorInfoElem = (ErrorInfoElement)CreateNewElement();
            Add(errorInfoElem);
        }

        public override ConfigurationElementCollectionType CollectionType
        {
            get
            {
                return ConfigurationElementCollectionType.AddRemoveClearMap;
            }
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new ErrorInfoElement();
        }

        protected override Object GetElementKey(ConfigurationElement element)
        {
            return ((ErrorInfoElement)element).ID;
        }

        public ErrorInfoElement this[int index]
        {
            get
            {
                return (ErrorInfoElement)BaseGet(index);
            }
            set
            {
                if (BaseGet(index) != null)
                {
                    BaseRemoveAt(index);
                }
                BaseAdd(index, value);
            }
        }

        new public ErrorInfoElement this[string name]
        {
            get
            {
                return (ErrorInfoElement)BaseGet(name);
            }
        }

        public int IndexOf(ErrorInfoElement transTypeElem)
        {
            return BaseIndexOf(transTypeElem);
        }

        public void Add(ErrorInfoElement errTypeElem)
        {
            BaseAdd(errTypeElem);
        }
        protected override void BaseAdd(ConfigurationElement element)
        {
            BaseAdd(element, false);
        }

        public void Remove(ErrorInfoElement errorTypeElem)
        {
            if (BaseIndexOf(errorTypeElem) >= 0)
                BaseRemove(errorTypeElem.ID);
        }

        public void RemoveAt(int index)
        {
            BaseRemoveAt(index);
        }

        public void Remove(string name)
        {
            BaseRemove(name);
        }

        public void Clear()
        {
            BaseClear();
        }


    }

    public class HelperUtility
    {

        public static string FormatString(string message1, string message2)
        {
            return string.Format("{0} {1}", message1, message2);
        }
        public static ErrorTypesSection RetrieveErrorTypeSectionInfoFromConfig(Configuration config)
        {
            //System.Configuration.Configuration config = null;
            try
            {
                //string binPath = System.IO.Path.Combine(HostingEnvironment.ApplicationPhysicalPath, "bin");
                //string dllPath = System.IO.Path.Combine(binPath, "NissanDCSProvider.dll");

               
                ErrorTypesSection errorTypeSection = config.GetSection("ErrorTypeInformation/ErrorTypeInfoManager") as ErrorTypesSection;


                if (errorTypeSection == null)
                {
                    throw new Exception("Error in RetrieveErrorTypeSectionInfoFromConfig method of HelperUtility class. The ErrorTypeInformation/ErrorTypeInfoManager section is invalid or does not have correct elements/attributes");
                }

                return errorTypeSection;

            }
            catch (ConfigurationErrorsException configEx)
            {
                throw new Exception("ConfigurationErrorsException: Error in RetrieveErrorTypeSectionInfoFromConfig method of HelperUtility class ", configEx);
            }
            catch (Exception ex)
            {
                throw new Exception("Error in RetrieveErrorTypeSectionInfoFromConfig method of HelperUtility class ", ex);

            }
        }
    }
}



