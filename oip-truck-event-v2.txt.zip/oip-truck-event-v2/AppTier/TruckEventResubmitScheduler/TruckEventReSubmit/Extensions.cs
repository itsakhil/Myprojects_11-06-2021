﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TruckEventReSubmit
{
    public static class Extensions
    {
        public static string ToLogError(this Exception exception,string extraMessage)
        {
            if (string.IsNullOrEmpty(extraMessage))
            {
                return string.Format("Error : {0}; StackTrace: {1}", exception.Message, exception.StackTrace);
            }
            else
            {
                return string.Format("Error : {0}; StackTrace: {1}", extraMessage, exception.StackTrace);
            }
        }

        public static bool CheckDataSetIfEmpty(this DataSet dataSet)
        {
            if (dataSet == null || dataSet.Tables.Count == 0 || dataSet.Tables[0].Rows.Count == 0)
            {
                return true;
            }
            return false;
        }

    }
}
