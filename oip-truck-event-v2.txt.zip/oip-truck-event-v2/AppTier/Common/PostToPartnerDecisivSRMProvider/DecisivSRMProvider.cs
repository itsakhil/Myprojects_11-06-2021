﻿using CDK.Data.OIP.API;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web.Hosting;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Xml.Xsl;

namespace PostToPartnerDecisivSRMProvider
{
    public class PostToPartnerDecisivSRMProvider : PostToPartnerGenericProvider.CommonAbstractProvider
    {
        /// <summary>
        /// PostMessageToPartner
        /// </summary>
        /// <param name="payLoad"></param>
        /// <param name="dictHeaders"></param>
        /// <returns></returns>
        public override string PostMessageToPartner(string payLoad, Dictionary<string, string> dictHeaders)
        {
            string strAppName = string.Empty;
            string strTransName = string.Empty;
            string strConversationId = string.Empty;
            string strConversationAppName = string.Empty;
            string strTransId = string.Empty;
            string strActivationId = string.Empty;
            string strVenders = string.Empty;
            string strErrorMessage = string.Empty;
            string strReturnXML = string.Empty;
            string strPartnerURL = string.Empty;
            string strConsumerKey = string.Empty;
            string strConsumerSecret = string.Empty;
            string strBearerToken = string.Empty;
            string strUpdateCaseXslt = string.Empty;
            string strResponse = string.Empty;
            string strPartnerTokenURL = string.Empty;
            string strPartnerPostURL = string.Empty;
            string strPayLoad = string.Empty;
            string strRetryCount = string.Empty;
            int intRetryCount = 0;
            int intStatusCode = 1; 
            bool isLogIncomming = false;
            Exception excep;

            try
            {
                strAppName = dictHeaders["AppName"].ToString();
                strTransName = dictHeaders["TransName"].ToString();
                strConversationId = dictHeaders["ConversationId"].ToString();
                strConversationAppName = dictHeaders["ConversationAppName"].ToString();
                strTransId = dictHeaders["TransId"].ToString();
                strActivationId = dictHeaders["ActivationId"].ToString();
                strVenders = dictHeaders["Venders"].ToString();
                strRetryCount = dictHeaders["RetryCount"].ToString();
                if (strRetryCount != string.Empty)
                    intRetryCount = int.Parse(strRetryCount);
                isLogIncomming = (bool.Parse(dictHeaders["strLogIncomming"].ToString()));

                strPayLoad = payLoad;

                string strVendorRONumber = string.Empty;
                XDocument xDoc = XDocument.Parse(payLoad);
                XNamespace xNs = ConfigurationManager.AppSettings["TruckEventXMLNameSpace"];

                if (xDoc.Descendants(xNs + "ROInfor").Descendants(xNs + "VendorRONumber") != null)
                    strVendorRONumber = xDoc.Descendants(xNs + "ROInfo").Descendants(xNs + "VendorRONumber").FirstOrDefault().Value;

                if (strVendorRONumber == string.Empty)
                {
                    intStatusCode = 1001;
                    throw new Exception("VendorRONumber field value is null or empty in " + strAppName + " PayLoad.");
                }
                //Extract PayLoad and validate VendorRONumber End

                int iExists = Routing.GetProperty(strAppName, "RoEventEndPointURL", ref strPartnerURL);
                if (!iExists.Equals(0))
                {
                    throw new Exception("Unable to retrieve RoEventEndPointURL property value from OIP Database. Please check under application " + strAppName + " the value for PartnerEndPointURL property.");
                }

                iExists = Routing.GetProperty(strAppName, "RoEventConsumerKey", ref strConsumerKey, Convert.ToInt32(strActivationId));
                if (!iExists.Equals(0))
                {
                    throw new Exception("Unable to retrieve RoEventConsumerKey property value from OIP Database. Please check under application " + strAppName + " the value for PartnerUserName property.");
                }

                iExists = Routing.GetProperty(strAppName, "RoEventConsumerSecret", ref strConsumerSecret, Convert.ToInt32(strActivationId));
                if (!iExists.Equals(0))
                {
                    throw new Exception("Unable to retrieve RoEventConsumerSecret property value from OIP Database. Please check under application " + strAppName + " the value for PartnerUserName property.");
                }

                iExists = Routing.GetProperty(strAppName, "RoEventBearerToken", ref strBearerToken, Convert.ToInt32(strActivationId));
                if (!iExists.Equals(0))
                {
                    throw new Exception("Unable to retrieve RoEventBearerToken property value from OIP Database. Please check under application " + strAppName + " the value for PartnerUserName property.");
                }

                //Get Bearer Token Begin
                if (string.IsNullOrEmpty(strBearerToken))
                {
                    strPartnerTokenURL = strPartnerURL + "/oauth2/token";
                    excep = GetBearerToken(strPartnerTokenURL, strConsumerKey, strConsumerSecret, ref strReturnXML, ref intStatusCode);
                    if (excep == null)
                    {
                        //Get BearerToken from response Begin
                        xDoc = XDocument.Parse(strReturnXML);
                        xNs = ConfigurationManager.AppSettings["DecisivXMLNameSpaceV07"];
                        if (xDoc.Descendants(xNs + "AuthorizationResponse").Descendants(xNs + "token") != null)
                            strBearerToken = xDoc.Descendants(xNs + "AuthorizationResponse").Descendants(xNs + "token").FirstOrDefault().Value;
                        //Get BearerToken from response End

                        if (strBearerToken != string.Empty)
                        {
                            iExists = Routing.SetProperty(strAppName, "RoEventBearerToken", strBearerToken, Convert.ToInt32(strActivationId));
                            if (!iExists.Equals(0))
                            {
                                throw new Exception("Unable to update RoEventBearerToken property value to OIP Database. Please check under application " + strAppName + " the value for PartnerUserName property.");
                            }
                        }
                    }
                    else
                    {
                        throw new Exception(excep.Message);
                    }
                }
                //Get Bearer Token End

                if (strTransName.ToUpper() == "CLOSERO")
                {
                    strUpdateCaseXslt = ConfigurationManager.AppSettings["DecisivUpdateCaseXslt"];
                    strResponse = Transform(payLoad, strUpdateCaseXslt, null, string.Empty, true, true, true);
                    payLoad = strResponse;
                }
                strPartnerPostURL = strPartnerURL;

                // Log incoming payLoad to filedep location ToOEM Begin
                if (isLogIncomming)
                {
                    string strFilePath = ConfigurationManager.AppSettings["LogToOEMPath"];
                    string fileName = string.Format("{0}~{1}~{2}~ToOEM.xml", strAppName, strTransName, strTransId);
                    string fullfilepath = System.IO.Path.Combine(string.Format(strFilePath, strAppName), fileName);
                    LogMessages(payLoad, fullfilepath,strAppName,strTransName,strTransId,strActivationId);
                }
                // Log incoming payLoad to filedep location ToOEM End

                if (strTransName.ToUpper() == "CLOSERO")
                {
                    //Uudate Case Begin
                    strPartnerPostURL = strPartnerURL + "/cases/" + strVendorRONumber;
                    excep = UpdateCase(payLoad, strPartnerPostURL, strBearerToken, ref strReturnXML, ref intStatusCode);

                    if (excep == null)
                    {
                        // Log response from UpdateCase to filedep location FromOEM Begin
                        if (isLogIncomming)
                        {
                            string strFilePath = ConfigurationManager.AppSettings["LogFromOEMPath"];
                            string fileName = string.Format("{0}~{1}~{2}~UpdateCase~FromOEM.xml", strAppName, strTransName, strTransId);
                            string fullfilepath = System.IO.Path.Combine(string.Format(strFilePath, strAppName), fileName);
                            LogMessages(strReturnXML, fullfilepath,strAppName,strTransName,strTransId,strActivationId);
                        }
                        // Log incoming payLoad to filedep location FromOEM End
                    }
                    else
                    {
                        throw new Exception(excep.Message);
                    }
                    //Uudate Case Begin

                    //Clsoe Case Begin
                    strPartnerPostURL = strPartnerURL + "/cases/" + strVendorRONumber + "/actions/close";
                    excep = CloseCase(payLoad, strPartnerPostURL, strBearerToken, ref strReturnXML, ref intStatusCode);

                    if (excep == null)
                    {
                        
                    }
                    else
                    {
                        throw new Exception(excep.Message);
                    }
                    //Clsoe Case Begin
                }
                //Log TimePoint3 SentToOEM Begin
                bool bResult = Convert.ToBoolean(TimePoints.MarkNext(strAppName, strTransId, 3, "GotFromPartner"));
                if (!bResult)
                {
                    strErrorMessage = "Failed to mark third time point for Activation:" + strActivationId;
                    throw new Exception(strErrorMessage);
                }
                //Log TimePoint3 SentToOEM End
                return intStatusCode.ToString();
            }
            catch (Exception ex)
            {
                string strError = string.Empty;
                string strTransactionStatus = string.Empty;
                bool retryRequired = false;

                if (intStatusCode != 1)
                {
                    string binPath = AppDomain.CurrentDomain.BaseDirectory;// System.IO.Path.Combine(HostingEnvironment.ApplicationPhysicalPath, "bin");
                    string dllPath = System.IO.Path.Combine(binPath, "PostToPartnerDecisivSRMProvider.dll");
                    System.Configuration.Configuration config = null;
                    if (config == null)
                    {
                        config = System.Configuration.ConfigurationManager.OpenExeConfiguration(dllPath);
                    }
                    else
                    {
                        strError = "Unable to find PostToPartnerDecisivSRMProvider.dll.config file.";
                    }
                    ErrorTypesSection errorSection = HelperUtility.RetrieveErrorTypeSectionInfoFromConfig(config);
                    ErrorInfoElement errorInforElement = errorSection.ErrorInfoManager[intStatusCode.ToString()];

                    if (errorInforElement != null)
                    {
                        strError = errorInforElement.LogDescription;
                        strTransactionStatus = "CompletedWithValidationErrors";
                        TimePoints.MarkNext(strAppName, strTransId, 3, strTransactionStatus);
                        TimePoints.MarkNext(strAppName, strTransId, 4, strTransactionStatus);
                        retryRequired = false;
                    }
                    else
                    {
                        strError = ex.Message.ToString() + strErrorMessage.ToString();
                        strTransactionStatus = "FailedToPostToPartner";
                        TimePoints.MarkNext(strAppName, strTransId, 3, strTransactionStatus);
                        retryRequired = true;
                    }
                }
                else
                {
                    strError = ex.Message.ToString() + strErrorMessage.ToString();
                    strTransactionStatus = "FailedToPostToPartner";
                    TimePoints.MarkNext(strAppName, strTransId, 3, strTransactionStatus);
                    retryRequired = true;
                }

               
                 //strError = ex.Message.ToString() + strErrorMessage.ToString();
                ErrorLog.LogMessage("PostToPartnerDecisivSRMProvider",3, strError, "", strAppName, strTransName, strTransId, strActivationId);
                intRetryCount++;
                string fileName = string.Format("{0}~{1}~{2}~{3}~{4}~{5}~{6}~{7}.xml", strAppName, strTransName, strConversationId, strConversationAppName, strTransId, strActivationId, strVenders, intRetryCount);
                string strFilePath = string.Empty;
                string fullfilepath = string.Empty;
                //LogError payload Beging
                if (retryRequired)
                {
                     strFilePath = ConfigurationManager.AppSettings["LogFailedToPostToPartner"];
                     fullfilepath = System.IO.Path.Combine(string.Format(strFilePath, strAppName), fileName);

                }
                else
                {
                    strFilePath = ConfigurationManager.AppSettings["ErrorsPath"];
                    fullfilepath = System.IO.Path.Combine(string.Format(strFilePath, strAppName), fileName);
                }
                LogMessages(strPayLoad, fullfilepath, strAppName, strTransName, strTransId, strActivationId);
                //LogError payload end
                return null;
            }
        }

        /// <summary>
        /// GetBearerToken
        /// </summary>
        /// <param name="strPartnerURL"></param>
        /// <param name="strConsumerKey"></param>
        /// <param name="strConsumerSecret"></param>
        /// <param name="strReturnXML"></param>
        /// <returns></returns>
        public Exception GetBearerToken(string strPartnerURL, string strConsumerKey, string strConsumerSecret, ref string strReturnXML, ref int intStatusCode)
        {
            string strMessage = string.Empty;
            HttpWebRequest request = null;
            HttpWebResponse response = null;
            Stream respStream = null;
            StreamReader rdr = null;

            try
            {
                request = (HttpWebRequest)WebRequest.Create(strPartnerURL);
                request.ContentType = "application/x-www-form-urlencoded";
                request.Headers.Add("Accept-Encoding", "gzip");
                request.Accept = "*/*";

                request.Method = "POST";
                string credentials = string.Concat(string.Concat(strConsumerKey, ":"), strConsumerSecret);
                request.Headers.Add("Authorization", "Basic " + Convert.ToBase64String(Encoding.UTF8.GetBytes(credentials)));

                using (HttpWebResponse response2 = (HttpWebResponse)request.GetResponse())
                {
                    using (StreamReader responseData = new StreamReader(response2.GetResponseStream()))
                    {
                        strReturnXML = responseData.ReadToEnd();
                        intStatusCode = (int)response2.StatusCode;
                        if (intStatusCode < 200 || intStatusCode > 299)
                        {
                            return new Exception("Invalid response from : " + strPartnerURL + " Response : " + strReturnXML + " Status Code " + intStatusCode.ToString());
                        }
                    }
                }
                return null;
            }

            catch (WebException webEx)
            {
                strMessage = "PostDocumentToPartner method: Web Exception:" + webEx.Message;
                strReturnXML = strMessage;
                try
                {
                    response = (HttpWebResponse)webEx.Response;
                    respStream = response.GetResponseStream();
                    rdr = new StreamReader(respStream, System.Text.Encoding.ASCII);
                    strReturnXML = rdr.ReadToEnd();
                    intStatusCode = (int)response.StatusCode;
                }
                catch (Exception)
                {
                    //Do nothing.
                }
                strMessage = "PostDocumentToPartner method: Web Exception:" + webEx.Message + " " + webEx.Response + " " + strPartnerURL;
                return new Exception(strMessage);
            }
            catch (Exception ex)
            {
                strMessage = "PostDocumentToPartner method: Exception:" + ex.Message + " " + ex.InnerException.Message;
                strReturnXML = ex.InnerException.Message;
                return new Exception(strMessage);
            }
            finally
            {
                if (rdr != null) rdr.Close();
                if (respStream != null) respStream.Close();
                if (response != null) response.Close();
            }
        }

        /// <summary>
        /// PostToPartner
        /// </summary>
        /// <param name="payLoad"></param>
        /// <param name="strPartnerURL"></param>
        /// <param name="strBearerToken"></param>
        /// <param name="strReturnXML"></param>
        /// <returns></returns>
        public Exception UpdateCase(string payLoad, string strPartnerURL, string strBearerToken, ref string strReturnXML, ref int intStatusCode)
        {
            string strMessage = string.Empty;
            HttpWebRequest request = null;
            HttpWebResponse response = null;
            Stream respStream = null;
            StreamReader rdr = null;

            try
            {
                request = (HttpWebRequest)WebRequest.Create(strPartnerURL);
                request.Headers.Add("Authorization", "Bearer " + strBearerToken);
                request.Headers.Add("Accept-Version", "1");
                request.ContentType = "application/xml";
                request.Accept = "application/vnd.decisiv.case+xml; version=0.1";
                request.Method = "POST";

                var encoder = new UTF8Encoding();
                var data = encoder.GetBytes(payLoad);
                request.Headers.Add("ContentLength", data.Length.ToString());
                var reqStream = request.GetRequestStream();
                reqStream.Write(data, 0, data.Length);
                reqStream.Close();
                reqStream = null;

                using (HttpWebResponse response2 = (HttpWebResponse)request.GetResponse())
                {
                    using (StreamReader responseData = new StreamReader(response2.GetResponseStream()))
                    {
                        strReturnXML = responseData.ReadToEnd();
                        intStatusCode = (int)response2.StatusCode;
                        if (intStatusCode < 200 || intStatusCode > 299)
                        {
                            return new Exception("Invalid response from : " + strPartnerURL + " Response : " + strReturnXML + " Status Code " + intStatusCode.ToString());
                        }
                    }
                }
                return null;
            }

            catch (WebException webEx)
            {
                strMessage = "PostDocumentToPartner method: Web Exception:" + webEx.Message;
                strReturnXML = strMessage;
                try
                {
                    response = (HttpWebResponse)webEx.Response;
                    respStream = response.GetResponseStream();
                    rdr = new StreamReader(respStream, System.Text.Encoding.ASCII);
                    intStatusCode = (int)response.StatusCode;
                    strReturnXML = rdr.ReadToEnd();
                }
                catch (Exception)
                {
                    //Do nothing.
                }
                strMessage = "PostDocumentToPartner method: Web Exception:" + webEx.Message + " " + webEx.Response + " " + strPartnerURL;
                return new Exception(strMessage);
            }
            catch (Exception ex)
            {
                strMessage = "PostDocumentToPartner method: Exception:" + ex.Message + " " + ex.InnerException.Message;
                strReturnXML = ex.InnerException.Message;
                return new Exception(strMessage);
            }
            finally
            {
                if (rdr != null) rdr.Close();
                if (respStream != null) respStream.Close();
                if (response != null) response.Close();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="payLoad"></param>
        /// <param name="strPartnerURL"></param>
        /// <param name="strBearerToken"></param>
        /// <param name="strReturnXML"></param>
        /// <returns></returns>
        public Exception CloseCase(string payLoad, string strPartnerURL, string strBearerToken, ref string strReturnXML, ref int intStatusCode)
        {
            string strMessage = string.Empty;
            HttpWebRequest request = null;
            HttpWebResponse response = null;
            Stream respStream = null;
            StreamReader rdr = null;

            try
            {
                request = (HttpWebRequest)WebRequest.Create(strPartnerURL);
                request.Headers.Add("Authorization", "Bearer " + strBearerToken);
                request.ContentType = "application/xml";
                request.Accept = "application/xml";
                request.Method = "PUT";

                using (HttpWebResponse response2 = (HttpWebResponse)request.GetResponse())
                {
                    using (StreamReader responseData = new StreamReader(response2.GetResponseStream()))
                    {
                        strReturnXML = responseData.ReadToEnd();
                        intStatusCode = (int)response2.StatusCode;
                        if (intStatusCode < 200 || intStatusCode > 299)
                        {
                            return new Exception("Invalid response from : " + strPartnerURL + " Response : " + strReturnXML + " Status Code " + intStatusCode.ToString());
                        }
                    }
                }
                return null;
            }

            catch (WebException webEx)
            {
                strMessage = "PostDocumentToPartner method: Web Exception:" + webEx.Message;
                strReturnXML = strMessage;
                try
                {
                    response = (HttpWebResponse)webEx.Response;
                    respStream = response.GetResponseStream();
                    rdr = new StreamReader(respStream, System.Text.Encoding.ASCII);
                    strReturnXML = rdr.ReadToEnd();
                    intStatusCode = (int)response.StatusCode;
                }
                catch (Exception)
                {
                    //Do nothing.
                }
                strMessage = "PostDocumentToPartner method: Web Exception:" + webEx.Message + " " + webEx.Response + " " + strPartnerURL;
                return new Exception(strMessage);
            }
            catch (Exception ex)
            {
                strMessage = "PostDocumentToPartner method: Exception:" + ex.Message + " " + ex.InnerException.Message;
                strReturnXML = ex.InnerException.Message;
                return new Exception(strMessage);
            }
            finally
            {
                if (rdr != null) rdr.Close();
                if (respStream != null) respStream.Close();
                if (response != null) response.Close();
            }
        }

        /// <summary>
        /// Transform
        /// </summary>
        /// <param name="srcPayload"></param>
        /// <param name="XSLTPath"></param>
        /// <param name="nvc"></param>
        /// <param name="XMLnamespace"></param>
        /// <param name="blnEnableXslSettings"></param>
        /// <param name="blnEnableScript"></param>
        /// <param name="blnEnableDocFunction"></param>
        /// <returns></returns>
        public string Transform(string srcPayload, string XSLTPath, NameValueCollection nvc, string XMLnamespace, bool blnEnableXslSettings, bool blnEnableScript, bool blnEnableDocFunction)
        {
            System.IO.StringReader sReader = null;
            System.Xml.XmlReader oXML = null;
            XsltSettings xslSettings = null;
            try
            {
                if (string.IsNullOrEmpty(srcPayload))
                {
                    throw new ArgumentNullException("The srcPayload parameter is null or empty");
                }
                // Argument list for XSL
                XsltArgumentList xslArgList = null;
                if (nvc != null && nvc.Count > 0)
                {
                    xslArgList = new XsltArgumentList();
                    for (int iIndex = 0; iIndex < nvc.Count; iIndex++)
                    {
                        xslArgList.AddParam(nvc.GetKey(iIndex), XMLnamespace, nvc.Get(iIndex));
                    }
                }

                if (blnEnableXslSettings)
                {
                    xslSettings = new XsltSettings();
                    xslSettings.EnableScript = blnEnableScript;
                    xslSettings.EnableDocumentFunction = blnEnableDocFunction;
                }
                // The XSLT stylesheet location

                sReader = new System.IO.StringReader(srcPayload);
                oXML = new XmlTextReader(sReader);

                XPathDocument xDoc = new System.Xml.XPath.XPathDocument(oXML);

                XslTransform xsl = new XslTransform();
                xsl.Load(XSLTPath);

                //XslCompiledTransform xsl = new XslCompiledTransform();
                //xsl.Load(System.Reflection.Assembly.Load(XSLTPath).GetType(XSLTPath));

                // The transformation results
                using (System.IO.MemoryStream ms = new MemoryStream())
                {
                    xsl.Transform(xDoc, xslArgList, ms);
                    ms.Position = 0;
                    using (System.IO.StreamReader sr = new StreamReader(ms))
                    {
                        return sr.ReadToEnd();
                    }
                }
            }
            catch (XsltException excpXsl)
            {
                throw new XsltException(string.Format("Error in Transform method of CustomerProviderInterface class. Error message is Failed to load XSL file XsltException : {0}", excpXsl.Message));
            }
            catch (DirectoryNotFoundException dirEX)
            {
                throw new DirectoryNotFoundException(string.Format("Error in Transform method of CustomerProviderInterface class. Error message is Failed to load XSL file DirectoryNotFoundException : {0}", dirEX.Message));
            }
            catch (FileNotFoundException fileEx)
            {
                throw new FileNotFoundException(string.Format("Error in Transform method of CustomerProviderInterface class. Error message is Failed to load XSL file FileNotFoundException : {0}", fileEx.Message));
            }
            finally
            {
                if (sReader != null) sReader.Close();
                if (oXML != null) oXML.Close();
            }
        }

        /// <summary>
        /// LogMessages
        /// </summary>
        /// <param name="Payload"></param>
        /// <param name="strFilePath"></param>
        public void LogMessages(string Payload, string strFilePath, string strAppName, string strTransName, string strTransId, string strActivationId)
        {
            string strErrorMsg = string.Empty;
            try
            {
                System.IO.File.WriteAllText(strFilePath, Payload);
            }
            catch (Exception ex)
            {
                strErrorMsg = "Not able to log the file " + ex.Message;
                ErrorLog.LogMessage("CDKTruckEventToOEMService", 3, strErrorMsg, "", strAppName, strTransName, strTransId, strActivationId);
               // throw new Exception(strErrorMsg);
            }
        }
    }
}
