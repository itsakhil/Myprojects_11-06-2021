﻿namespace TruckDMStoiServerEventingHandler
{
    using CDK.Data.OIP.API;
    using System;
    using System.Configuration;
    using System.Diagnostics;
    using System.Web;
    /// <summary>
    /// Summary description for TruckEventingHandler
    /// </summary>
    public class TruckEventingHandler : IHttpHandler
    {
        public delegate string ProcessorDelegate(out int statuscode);
      
        public TruckEventingHandler()
        {
                
        }
        public void ProcessRequest(HttpContext context)
        {
            HttpRequest request = context.Request;
            var strMessage = string.Empty;
            var statusCode = 200;
            RequestProcessor objRequestProcessor = new RequestProcessor(request);
            try
            {
                if (ConfigurationManager.AppSettings["Debug"].ToUpper() == "TRUE")
                {
                    context.Response.Write("<b>Hello World - TruckHandler</b><BR>");
                    context.Response.Write(" ProcessID : " + Process.GetCurrentProcess().Id);
                    return;
                }
                if (request.TotalBytes == 0)
                {
                    strMessage = "Document not received from DMS.";
                }
                else
                {
                    if (!objRequestProcessor.VerifyTransaction())
                    {
                        strMessage = objRequestProcessor.ErrorMessage;
                        statusCode = 500;
                    }
                    else
                    {

                        strMessage = objRequestProcessor.ErrorMessage;
                        if (!string.IsNullOrEmpty(objRequestProcessor.ErrorMessage))
                            statusCode = 500;
                        else
                        {

                            strMessage = objRequestProcessor.CreateResponse(true, "Success", 200);
                            statusCode = 200;
                        }
                        ProcessorDelegate processorDelegate = new ProcessorDelegate(objRequestProcessor.ProcessRequest);
                        IAsyncResult asynResult = processorDelegate.BeginInvoke(out statusCode, null, null);
                        //strMessage = objRequestProcessor.ProcessRequest(out statusCode);    

                    }
                }
                
            }
            catch (Exception exception)
            {
                ErrorLog.LogMessage("ProcessRequest", 3,objRequestProcessor.FormatErrorMessage(exception.ToString(),true) );
                var errorBytes = context.Request.BinaryRead(context.Request.TotalBytes);
                objRequestProcessor.logRequest(errorBytes, ConfigurationManager.AppSettings["ErrorSaveLocation"], true);
            }
            finally
            {
                context.Response.AddHeader("Content-Length", strMessage.Length.ToString());
                //context.Response.AddHeader("Content-Type", "text/xml");
                context.Response.ContentType = "application/xml";
                context.Response.Write(strMessage);
                context.Response.StatusCode = statusCode;
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}