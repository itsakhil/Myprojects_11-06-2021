﻿using CDK.Data.OIP.API;
using System;
using System.Configuration;
using System.IO;
using System.Linq;
using CDK.Data.OIP.GenericUtility;
using Truck.Common;

namespace TruckROSchedulerToOEM
{
    class Program
    {
        private static string _appName = "";

        static void Main(string[] args)
        {
            try
            {
                _appName = args[0];
                ProcessDecisiveMessage processDecisiveMessage = new ProcessDecisiveMessage(_appName);
                string payloadPath = ConfigurationManager.AppSettings["PayloadPath"];
                payloadPath = String.Format(payloadPath, _appName);

                string logInProcess = ConfigurationManager.AppSettings["LogInProcess"];
                logInProcess = String.Format(logInProcess, _appName);

                string archivePath = String.Format(ConfigurationManager.AppSettings["ArchivePath"], _appName);
                string errorsPath = String.Format(ConfigurationManager.AppSettings["ErrorsPath"], _appName);

                int.TryParse(ConfigurationManager.AppSettings["MaxFilesToProcess"], out var maxFilesToProcess);

                DirectoryInfo directory = new DirectoryInfo(payloadPath);
                var fileCollection = directory.EnumerateFiles("*.xml")
                    .OrderBy(a => a.CreationTime).Take(maxFilesToProcess).ToArray();

                foreach (FileInfo fl in fileCollection)
                {
                    MoveFile(fl.Name, payloadPath, logInProcess, true);
                }

                foreach (FileInfo filelist in fileCollection)
                {
                    string payload = File.ReadAllText(Path.Combine(logInProcess, filelist.Name));
                    bool res = processDecisiveMessage.ProcessMessage(filelist.Name, payload);
                    if (res)
                    {
                        string destinationPath = Path.Combine(archivePath ,filelist.Name);
                        FileSystemUtility.QuickMove(Path.Combine(logInProcess, filelist.Name), destinationPath);
                    }
                    else
                    {
                        string destinationPath = Path.Combine(errorsPath , filelist.Name);
                        FileSystemUtility.QuickMove(Path.Combine(logInProcess, filelist.Name), destinationPath);
                    }
                }
            }
            catch (Exception exception)
            {
                MessageHelper objMessageHelper = new MessageHelper();
                ErrorLog.LogMessage("TruckROSchedulerToOEM", 3, objMessageHelper.FormatErrorMessage(exception.ToString(), true), String.Empty, _appName,
                    ConfigurationManager.AppSettings["TransName"], Guid.NewGuid().ToString(), 0);
            }
        }

        private static void MoveFile(string Filename, string Source, string Destination, bool OverWrite)
        {
            try
            {
                File.Copy(Path.Combine(Source, Filename), Path.Combine(Destination, Filename), OverWrite);

                File.Delete(Path.Combine(Source, Filename));

            }
            catch (Exception ex)
            {
                throw new Exception("Error in MoveFile method. " + ex.Message);
            }
        }
    }
}
