﻿console.log('Went to App js');

var http = require('http');
var fs = require('fs');
var Path = require('path');
var Stream = require('stream');
var urlParser = require('url');
var querystringbuilder = require('querystring');
var config = require('config');
var port = 1337;
var amqp = require("amqp");

var appsettings;
if (config.has('Configuration.AppSettings')) {
    appsettings = config.get('Configuration.AppSettings');
}
var gobaldata = '';


var HandlerRequest = function(req, res) {

    if (req.method == 'POST') {
        //var headers = JSON.stringify(req.headers);

        var url_parts = urlParser.parse(req.url, true).query;
        //var venders = req.headers.vendors.split(',');
        var venders = req.headers['vendors'].split(',');
        var venderString = req.headers['vendors'];

        console.log(venders);
        //console.log(url_parts);
        var routings = [];
        var activationId = {};
        for (i = 0; i < venders.length; i++) {
            var vendorName = venders[i].split(':');
            routings.push(vendorName[0]);
            activationId[vendorName[0]] = vendorName[1];
        }
        var routingKey = routings.join('.');
        var metadata = { TransactionName: url_parts.TransName, TransID: url_parts.TransID, AppName: url_parts.AppName, venders: venderString };
        MarkTimePoint(metadata, function(a, b) {
            console.log('MarkTime point called');
            CreateConversation(metadata, function(a, b) {
                console.log('Conversation Created');
            });
        });

        var queryData = '';

        req.on('data', function(data) {
            queryData += data;
        });

        req.on('end', function() {
            //console.log(queryData);
            gobaldata = queryData;
            var data = {ActivationId: venderString, AppName: url_parts.AppName, TransID: url_parts.TransID, TransName: url_parts.TransName };
            SendMessage(routingKey, queryData, data);
        });
        //var queryData = '';
        //req.on('data', function (data) {
        //    queryData += data;
        //});
        //console.log(req.post);
        console.log("Ok Status");
        res.writeHead(200, "OK", { 'Content-Type': 'text/html' });
        res.end('<html><head><title>200</title></head><body><h1>.</h1></body></html>');
        //res.end();
        console.log("W");
    } else {
        console.log("Ok Status");
        res.writeHead(200, "OK", { 'Content-Type': 'text/html' });
        res.end('<html><head><title>200 - Method not supported</title></head><body><h1>Method not supported.</h1></body></html>');
        //res.end();
        console.log("W");

        //console.log("[405] " + req.method + " to " + req.url);
        //res.writeHead(405, "Method not supported", { 'Content-Type': 'text/xml' });

    }

};
var SendMessage = function (routingKey, content, properties) {
    var isErrorSend = 0;
    var conn = amqp.createConnection({ host: appsettings.Host, login: appsettings.Login, password: appsettings.Password, port: appsettings.Port , vhost: appsettings.Vhost });
    conn.addListener('error', function (e) {
        console.log('Main Connection Error Called');
        SaveMessageWithError(properties, content, e, isErrorSend);
        isErrorSend = 1;
        //conn.disconnect();
    });
    //console.log(conn);
    conn.on('ready', function () {
        console.log("Function called");
        
        conn.exchange(appsettings.ROClose, { type: 'topic', durable: true, autoDelete: false }, function (exchange) {
            // console.log(exchange);
            console.log('Exchange ' + exchange.name + ' is open');
            console.log('Exchange state ' + exchange.state);
            
            exchange.addListener('error', function (e) {
                console.log('Exchange Error Listner');
                SaveMessageWithError(properties, content, e, isErrorSend);
                isErrorSend = 1;
                //conn.disconnect();
            });
            console.log('got exchange');
            
            //exchange.publish('', myText, { contentType: 'text/plain' }, function (a, b) { console.log('Send'); });
            exchange.publish(routingKey, content, { headers: { 'venders': properties.ActivationId, 'transsType': properties.TransName }, messageId: properties.TransID, type: 'application/xml' }, function (a, b) {
                console.log('Message Callback Callled');
            });
            console.log("publish done on RabbitMQ........" + routingKey);
        });

    });
};

var SaveMessageWithError = function (properties, content, error, isErrorSend) {
    if (isErrorSend == 0) {
        properties.Source = 'SendMessage';
        properties.EventLevel = 3;
        properties.Message = error;
        SaveFile(content, properties);
        LogError(properties, function (a, b) {
            console.log('Error Log Completed');
        });
    }
};

var CreateConversation = function (parameters, callback) {
    var soapXml = '<?xml version="1.0" encoding="utf-8"?> ' 
        + '<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">' 
        + '<soap:Body>' 
        + '<ConversationCreate xmlns="http://iServer.DealerServices.ADP.com/ConversationUtility">' 
        + '<strAppName>' + parameters.AppName + '</strAppName>' 
        + '<strConversationID>' + parameters.TransID + '</strConversationID>' 
        + '<strConversationStatus>Open</strConversationStatus>' 
        + '<strConversationProcessingStatus>Inprogress</strConversationProcessingStatus>' 
        + '<strInitiatorTransID>' + parameters.TransID + '</strInitiatorTransID>' 
        + '<nQueueCount>0</nQueueCount>' 
        + '</ConversationCreate>' 
        + '</soap:Body>' 
        + '</soap:Envelope>';
    
    var post_options = {
        host: '172.29.214.250',
        port: '80',
        path: '/iServerUtility/ConversationUtility.asmx',
        method: 'POST',
        headers: {
            'Content-Type': 'text/xml',
            'Content-Length': soapXml.length,
            'SOAPAction': 'http://iServer.DealerServices.ADP.com/ConversationUtility/ConversationCreate'
        }
    };
    // Set up the request
    var post_req = http.request(post_options, function (res) {
        res.setEncoding('utf8');
        res.on('data', function (chunk) {
            //console.log('Response: ' + chunk);
            callback(null, chunk);
        });
    });
    
    post_req.write(soapXml);
    post_req.end();
}

var SaveFile = function (document, parameters) {
    var filepath = appsettings.FilePath;
    var fileName = parameters.AppName + '_' + parameters.TransName + '_' + parameters.TransID + 'FromDML.xml';
    filepath = Path.join(filepath, fileName);
    fs.writeFile(filepath, document, null, function (err, success) {
        console.log('Error occured while writing file.');
    });

}

var MarkTimePoint = function (metadata, callback) {
    
    
    var soapXml = '<?xml version=\"1.0\" encoding=\"utf-8\"?>' 
    + '<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">' 
    + '<soap:Body>' 
      + '<MarkFirstPointExtra xmlns=\"http://iServer.DealerServices.ADP.com/iServerAPI/TimePoints\">' 
       + '<sTransTypeName>' + metadata.TransactionName + '</sTransTypeName>' 
        + '<sApplication>' + metadata.AppName + '</sApplication>' 
         + '<sTransID>' + metadata.TransID + '</sTransID>' 
            + '<sDealerCode>' + appsettings.DealorCode + '</sDealerCode>' 
            + '<sExtraCriteria></sExtraCriteria>' 
            + '<sStatus>Initiated</sStatus>' 
            + '<sExtraField>' + metadata.venders + '</sExtraField>' 
            + '</MarkFirstPointExtra>' 
            + '</soap:Body>' 
            + '</soap:Envelope>';
    
    var post_options = {
        host: '172.29.214.160',
        port: '80',
        path: '/iserverapi/TimePoints.asmx',
        method: 'POST',
        headers: {
            'Content-Type': 'text/xml',
            'Content-Length': soapXml.length,
            'SOAPAction': 'http://iServer.DealerServices.ADP.com/iServerAPI/TimePoints/MarkFirstPointExtra'
        }
    };
    
    // Set up the request
    var post_req = http.request(post_options, function (res) {
        res.setEncoding('utf8');
        res.on('data', function (chunk) {
            //console.log('Response: ' + chunk);
            callback(null, chunk);
        });
    });
    
    post_req.write(soapXml);
    post_req.end();

}

var LogError = function (metadata, callback) {
    var soapXml = '<?xml version="1.0" encoding="utf-8"?>' 
        + '<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">' 
        + '<soap:Body>' 
        + '<LogMessageDC xmlns="http://iServer.DealerServices.ADP.com/iServerAPI/ErrorLog">' 
        + '<strSource>' + metadata.Source + '</strSource>' 
        + '<nEventLevel>' + metadata.EventLevel + '</nEventLevel>' 
        + '<strDealerCode>' + appsettings.DealorCode + '</strDealerCode>' 
        + '<strTransID>' + metadata.TransID + '</strTransID>' 
        + '<strAppName>' + metadata.AppName + '</strAppName>' 
        + '<strTransTypeName>' + metadata.TransName + '</strTransTypeName>' 
        + '<strMessage>Error in SendMessage method of NodeJs component. ' + metadata.Message + '</strMessage>' 
        + '</LogMessageDC>' 
        + '</soap:Body>' 
        + '</soap:Envelope>';
    
    var post_options = {
        host: '172.29.214.160',
        port: '80',
        path: '/iserverapi/ErrorLog.asmx',
        method: 'POST',
        headers: {
            'Content-Type': 'text/xml',
            'Content-Length': soapXml.length,
            'SOAPAction': 'http://iServer.DealerServices.ADP.com/iServerAPI/ErrorLog/LogMessageDC'
        }
    };
    
    // Set up the request
    var post_req = http.request(post_options, function (res) {
        res.setEncoding('utf8');
        res.on('data', function (chunk) {
            //console.log('Response: ' + chunk);
            callback(null, chunk);
        });
    });
    
    post_req.write(soapXml);
    post_req.end();
}

http.createServer(HandlerRequest).listen(port);

/*
   
    
    var conn = amqp.createConnection({ host: '172.29.214.198', login: 'rmqadmin', password: 'N150umber', port: 5672 , vhost:'Events'});
    conn.addListener('error', function(e) {
        throw e;
    });
    //console.log(conn);
    conn.on('ready', function () {
        console.log("Function called");
        
        var queue;
        
        conn.exchange('Truck.Events.RepairOrder', {  type: 'topic', durable: true, autoDelete: false }, function (exchange) {
            console.log(exchange);
            console.log('Exchange ' + exchange.name + ' is open');
        console.log('Exchange state ' + exchange.state);
            console.log('Exchange connection ' + exchange.connection );
             
            exchange.addListener('error', function (e) {
                throw e;
            });
            console.log('got exchange');
            
            var myText = 'sample text message';
            exchange.addListener("error", function (e) {
                console.log("Message errro");
            });
            //exchange.publish('', myText, { contentType: 'text/plain' }, function (a, b) { console.log('Send'); });
            exchange.publish('DecsiviCRM.UpTimePro.NNA', {data: myText });
            console.log("publish done on RabbitMQ........" + myText);
        });

    });        






//var context = require('rabbit.js').createContext('amqp://rmqadmin:N150umber@172.29.214.198:5672');
//console.log(context);
//var pub = context.socket('PUB');
////pub.connect('alerts');
//pub.connect('Truck.Events.RepairOrder', function () {
//    console.log('get exchange');
//    setInterval(function () {
//        console.log('Message');
//        pub.publish(JSON.stringify({ request: 'content' }), 'utf8');
//    }, 1000);
//});
 * 
 * */