﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TruckEventReSubmit
{
    public class ConfigurationDetails
    {
        public string FailedToPublishPath { get; set; }
        public string HandlerUrl { get; set; }
        public string RabbitHostName { get; set; }
        public string RabbitPort { get; set; }
        public string RabbitUserName { get; set; }
        public string RabbitPassword { get; set; }
        public string RabbitVhost { get; set; }
        public string AppName { get; set; }
        public int RetryCount { get; set; }
        public int BatchCount { get; set; }
        public string ArchiveLocation { get; set; }
        public string ErrorLocation { get; set; }
        public string InProgressPath { get; set; }
        public string TransType { get; set; }

        public ConfigurationDetails()
        {
            FailedToPublishPath = ConfigurationManager.AppSettings["ServiceErrorPath"];
            HandlerUrl = ConfigurationManager.AppSettings["HandlerUrl"];
            RabbitHostName = ConfigurationManager.AppSettings["RabbitHostName"];
            RabbitPort = ConfigurationManager.AppSettings["RabbitPort"];
            RabbitUserName = ConfigurationManager.AppSettings["RabbitUserName"];
            RabbitPassword = ConfigurationManager.AppSettings["RabbitPassword"];
            RabbitVhost = ConfigurationManager.AppSettings["RabbitVhost"];
            AppName = ConfigurationManager.AppSettings["AppName"];
            ArchiveLocation = ConfigurationManager.AppSettings["ArchivePath"];
            ErrorLocation = ConfigurationManager.AppSettings["ErrorPath"];
            InProgressPath = ConfigurationManager.AppSettings["InProcess"];
            TransType = ConfigurationManager.AppSettings["TransType"];
            RetryCount = Convert.ToInt32(ConfigurationManager.AppSettings["RetryLimit"]);
            BatchCount = Convert.ToInt32(ConfigurationManager.AppSettings["BatchCount"]);
        }

        public string GetSpecificParameter(string name)
        {
            return ConfigurationManager.AppSettings[name];
        }
    }
}
