﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrome
{
    class Checkpalindrome
    {
        public void check()
        {
            string name=string.Empty;
            string reverse_name = string.Empty;
            try
            {
                name = System.Configuration.ConfigurationManager.AppSettings["Word"].ToString();

                if (string.IsNullOrEmpty(name) || string.IsNullOrWhiteSpace(name))
                {
                    Console.WriteLine("please provide input in App config file ");
                    throw new Exception("string contains white spaces");
                }
                for (int i = name.Length - 1; i >= 0; i--)
                {
                    reverse_name += name[i].ToString();
                }
                if (reverse_name.Equals( name,StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine("String Entered in webconfig is a palindrome");
                }
                else
                {
                    Console.WriteLine("String placed  in webconfig is not a palindrome");

                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception occured at  " + e.Message + e.StackTrace);
                throw;

            }
            Console.ReadKey();
        }

    }
}
